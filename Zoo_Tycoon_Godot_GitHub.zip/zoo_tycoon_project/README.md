# Zoo Tycoon: From Broke to Billionaire

A Godot 4 top-down zoo management prototype prepared for Android APK export via GitHub Actions.

## Included gameplay

- Top-down zoo world with grid-like terrain and exhibits.
- Build mode for paths, fences, habitats, benches, trees, bins, and kiosks.
- Animal capsule shop with incubation/hatching timers.
- Animal collection, feeding, happiness/hunger, ticket pricing, visitors, operating costs, reputation, staff, upgrades, and land expansion.
- Local save/load using `user://zoo_tycoon_save.json`.
- User-provided sprite sheets included under `assets/` and used for selected animal/tree sprites. Some visuals are drawn procedurally as a fallback.
- GitHub Actions workflow to export a debug APK.

## Run locally

1. Install Godot 4.4.1.
2. Open `project.godot` in Godot.
3. Run the main scene.

## Build APK on GitHub

1. Create a GitHub repository.
2. Upload the contents of this project folder so `project.godot` is at the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Zoo Tycoon Android APK** with **Run workflow**, or push to `main`/`master`.
5. Open the completed workflow run and download the `ZooTycoon-Android-APK` artifact.

The workflow installs Godot 4.4.1, its matching export templates, Java 17, and Android SDK components. The APK is a debug build for testing. A successful build must be confirmed by an actual GitHub Actions run; it is not claimed as tested here.

## Controls

- Desktop: WASD or arrow keys to move the camera.
- Click a construction tool, then click the map to place it.
- Use the bottom buttons for building, animal shop, collection, upgrades, staff, finances, and saving.
- Android: tap menu buttons and the map.

## Note

This is a playable foundation/prototype rather than a finished commercial-scale tycoon game. The included sprite sheets are source sheets with labels; some atlas crops may need adjustment to improve sprite boundaries and visual quality. More advanced navigation, staff AI, enclosure containment validation, audio, and polished animation remain future improvements.
