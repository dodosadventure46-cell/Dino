# Zoo Tycoon: From Broke to Billionaire

A Godot 4 top-down zoo management prototype prepared for Android APK export via GitHub Actions.

## Included gameplay

- Top-down zoo world with grid-like terrain and exhibits.
- Build mode for paths, fences, habitats, benches, trees, bins, and kiosks.
- Animal capsule shop with incubation/hatching timers.
- Animal collection, feeding, happiness/hunger, ticket pricing, visitors, operating costs, reputation, staff, upgrades, and land expansion.
- Local save/load using `user://zoo_tycoon_save.json`.
- User-provided sprite sheets included under `assets/` and used for selected animal/tree sprites. Some visuals are drawn procedurally as a fallback.
- GitHub Actions workflow to export a debug APK.

## Run locally

1. Install Godot 4.4.1.
2. Open `project.godot` in Godot.
3. Run the main scene.

## Build APK on GitHub

Cara 1 (tanpa ekstrak ZIP):
1. Buat repo GitHub, upload `Zoo_Tycoon_Godot_GitHub.zip` apa adanya ke root repo.
2. Buat file `.github/workflows/build-apk.yml` (isi dari `build-apk.yml`).
3. Buka **Actions -> Build Zoo Tycoon APK -> Run workflow**.

Cara 2 (proyek sudah diekstrak): upload isi folder proyek sehingga `project.godot` ada di root repo. Workflow di `.github/workflows/android-build.yml` ikut terpakai.

Hasil: unduh artifact `ZooTycoon-Android-APK`. Jika gagal, unduh artifact `build-logs` (import.log, script-check.log, export.log) untuk melihat penyebabnya.

## Controls

- Desktop: WASD or arrow keys to move the camera.
- Click a construction tool, then click the map to place it.
- Use the bottom buttons for building, animal shop, collection, upgrades, staff, finances, and saving.
- Android: tap menu buttons and the map.

## Note

This is a playable foundation/prototype rather than a finished commercial-scale tycoon game. The included sprite sheets are source sheets with labels; some atlas crops may need adjustment to improve sprite boundaries and visual quality. More advanced navigation, staff AI, enclosure containment validation, audio, and polished animation remain future improvements.
