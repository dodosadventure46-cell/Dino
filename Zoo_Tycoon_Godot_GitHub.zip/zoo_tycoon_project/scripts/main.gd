extends Node2D

const TILE := 48
const MAP_W := 42
const MAP_H := 28
const SAVE_PATH := "user://zoo_tycoon_save.json"
const ANIMAL_SHEET := preload("res://assets/animals/animal_dinosaur_spritesheet.png")
const BUILD_SHEET := preload("res://assets/environment/zoo_building_fence_spritesheet.png")
const PEOPLE_SHEET := preload("res://assets/visitors/visitors_staff_environment_spritesheet.png")

var cash: int = 850
var reputation: int = 1
var ticket_price: int = 15
var day: int = 1
var visitors_today: int = 0
var total_visitors: int = 0
var income_today: int = 0
var expense_today: int = 0
var selected_tool: String = "select"
var animals: Array[Dictionary] = []
var objects: Array[Dictionary] = []
var eggs: Array[Dictionary] = []
var staff_count: int = 0
var game_minutes: float = 0.0
var ui: CanvasLayer
var hud_label: Label
var status_label: Label
var panel: PanelContainer
var panel_box: VBoxContainer
var world_offset := Vector2(120, 82)
var cam_offset := Vector2.ZERO
var visitor_positions: Array[Vector2] = []
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	_load_game()
	_build_ui()
	set_process(true)
	queue_redraw()

func _process(delta: float) -> void:
	game_minutes += delta
	if game_minutes >= 12.0:
		game_minutes = 0.0
		_simulate_tick()
	if Input.is_action_pressed("move_up"):
		cam_offset.y += 230.0 * delta
	if Input.is_action_pressed("move_down"):
		cam_offset.y -= 230.0 * delta
	if Input.is_action_pressed("move_left"):
		cam_offset.x += 230.0 * delta
	if Input.is_action_pressed("move_right"):
		cam_offset.x -= 230.0 * delta
	queue_redraw()

func _simulate_tick() -> void:
	for egg in eggs:
		egg["time"] = int(egg.get("time", 0)) - 1
	for i in range(eggs.size() - 1, -1, -1):
		if int(eggs[i].get("time", 0)) <= 0:
			var species: String = str(eggs[i].get("species", "Kelinci"))
			animals.append({"species": species, "x": 520 + rng.randi_range(-30, 30), "y": 340 + rng.randi_range(-20, 20), "hunger": 100, "happiness": 85, "level": 1})
			_set_status("Telur menetas! " + species + " sekarang menjadi koleksi kebun binatangmu.")
			eggs.remove_at(i)
	for animal in animals:
		animal["hunger"] = max(0, int(animal.get("hunger", 100)) - 1)
		if int(animal["hunger"]) < 35:
			animal["happiness"] = max(0, int(animal.get("happiness", 80)) - 2)
	var base_visitors := max(1, 2 + animals.size() * 2 + reputation)
	var new_visitors := rng.randi_range(base_visitors, base_visitors + 3)
	visitors_today += new_visitors
	total_visitors += new_visitors
	var income := new_visitors * ticket_price
	var upkeep := animals.size() * 4 + staff_count * 8 + objects.size()
	cash += income - upkeep
	income_today += income
	expense_today += upkeep
	if cash < 0:
		cash = 0
	if visitors_today > 20:
		reputation = min(100, reputation + 1)
	if game_minutes == 0.0:
		_refresh_hud()

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	ui.add_child(root)
	var top := PanelContainer.new()
	top.position = Vector2(12, 10)
	top.size = Vector2(780, 58)
	_style_panel(top, Color("172b26"))
	root.add_child(top)
	hud_label = Label.new()
	hud_label.add_theme_font_size_override("font_size", 18)
	top.add_child(hud_label)
	var bar := HBoxContainer.new()
	bar.position = Vector2(12, 625)
	bar.size = Vector2(1250, 78)
	bar.add_theme_constant_override("separation", 8)
	root.add_child(bar)
	_add_button(bar, "Bangun", func(): _show_build_menu())
	_add_button(bar, "Toko Hewan", func(): _show_animal_shop())
	_add_button(bar, "Koleksi", func(): _show_animals())
	_add_button(bar, "Upgrade", func(): _upgrade_selected())
	_add_button(bar, "Staf", func(): _hire_staff())
	_add_button(bar, "Keuangan", func(): _show_finances())
	_add_button(bar, "Simpan", func(): _save_game())
	_add_button(bar, "Bantuan", func(): _show_help())
	status_label = Label.new()
	status_label.position = Vector2(15, 77)
	status_label.size = Vector2(800, 30)
	status_label.add_theme_color_override("font_color", Color("#fff2c6"))
	status_label.add_theme_font_size_override("font_size", 16)
	root.add_child(status_label)
	panel = PanelContainer.new()
	panel.position = Vector2(900, 88)
	panel.size = Vector2(350, 510)
	panel.visible = false
	_style_panel(panel, Color("#182b2a"))
	root.add_child(panel)
	panel_box = VBoxContainer.new()
	panel_box.add_theme_constant_override("separation", 8)
	panel.add_child(panel_box)
	_refresh_hud()

func _style_panel(p: PanelContainer, color: Color) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.border_color = Color("#75b78b")
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	p.add_theme_stylebox_override("panel", sb)

func _add_button(parent: Container, label: String, action: Callable) -> void:
	var b := Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(105, 54)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 16)
	b.pressed.connect(action)
	parent.add_child(b)

func _clear_panel(title: String) -> void:
	panel.visible = true
	for child in panel_box.get_children():
		child.queue_free()
	var heading := Label.new()
	heading.text = title
	heading.add_theme_font_size_override("font_size", 23)
	heading.add_theme_color_override("font_color", Color("#f8d88a"))
	panel_box.add_child(heading)
	var close := Button.new()
	close.text = "Tutup"
	close.pressed.connect(func(): panel.visible = false)
	panel_box.add_child(close)

func _menu_button(text_value: String, description: String, cost: int, action: Callable) -> void:
	var b := Button.new()
	b.text = text_value + " — " + description + " ($" + str(cost) + ")"
	b.custom_minimum_size.y = 42
	b.pressed.connect(action)
	panel_box.add_child(b)

func _show_build_menu() -> void:
	_clear_panel("Mode Pembangunan")
	_menu_button("Jalan", "membuat jalur", 8, func(): _set_tool("path"))
	_menu_button("Pagar kayu", "segmen pagar", 18, func(): _set_tool("fence"))
	_menu_button("Kandang", "habitat hewan", 120, func(): _set_tool("enclosure"))
	_menu_button("Bangku", "kenyamanan pengunjung", 45, func(): _place_object("Bangku", 45, Color("#a87948")))
	_menu_button("Pohon", "dekorasi", 35, func(): _place_object("Pohon", 35, Color("#3e8c48")))
	_menu_button("Tempat sampah", "kebersihan", 30, func(): _place_object("Tempat sampah", 30, Color("#7e9a9b")))
	_menu_button("Kios makanan", "pendapatan tambahan", 180, func(): _place_object("Kios makanan", 180, Color("#d58c43")))
	_menu_button("Perluas lahan", "naikkan reputasi", 350, func(): _expand_land())

func _show_animal_shop() -> void:
	_clear_panel("Toko Hewan & Telur")
	_menu_button("Kapsul Kelinci", "umum • cepat menetas", 100, func(): _buy_egg("Kelinci", 100, 2))
	_menu_button("Kapsul Rusa", "tidak umum", 240, func(): _buy_egg("Rusa", 240, 3))
	_menu_button("Kapsul Zebra", "menarik pengunjung", 420, func(): _buy_egg("Zebra", 420, 4))
	_menu_button("Kapsul Singa", "langka", 850, func(): _buy_egg("Singa", 850, 5))
	_menu_button("Kapsul Harimau", "langka", 1000, func(): _buy_egg("Harimau", 1000, 5))
	_menu_button("Telur T-Rex", "dinosaurus legendaris", 3500, func(): _buy_egg("T-Rex", 3500, 8))
	var note := Label.new()
	note.text = "Kapsul hewan mamalia adalah teknologi fiksi dalam game. Telur/kapsul akan menetas berdasarkan waktu game."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel_box.add_child(note)

func _show_animals() -> void:
	_clear_panel("Koleksi Hewan")
	if animals.is_empty():
		var empty := Label.new()
		empty.text = "Belum ada hewan. Beli kapsul di Toko Hewan."
		panel_box.add_child(empty)
	else:
		for i in range(animals.size()):
			var a: Dictionary = animals[i]
			var b := Button.new()
			b.text = str(a["species"]) + " | Lapar " + str(a["hunger"]) + "% | Bahagia " + str(a["happiness"]) + "%"
			b.custom_minimum_size.y = 44
			b.pressed.connect(func(): _feed_animal(i))
			panel_box.add_child(b)
	var egg_label := Label.new()
	egg_label.text = "Kapsul menetas: " + str(eggs.size())
	panel_box.add_child(egg_label)
	for e in eggs:
		var l := Label.new()
		l.text = str(e["species"]) + " — " + str(e["time"]) + " tick lagi"
		panel_box.add_child(l)

func _show_finances() -> void:
	_clear_panel("Laporan Keuangan")
	for line in ["Uang tersedia: $" + str(cash), "Hari: " + str(day), "Pengunjung hari ini: " + str(visitors_today), "Total pengunjung: " + str(total_visitors), "Pendapatan hari ini: $" + str(income_today), "Biaya operasional: $" + str(expense_today), "Reputasi kebun binatang: " + str(reputation), "Harga tiket: $" + str(ticket_price)]:
		var l := Label.new()
		l.text = line
		l.add_theme_font_size_override("font_size", 17)
		panel_box.add_child(l)
	var price := HBoxContainer.new()
	panel_box.add_child(price)
	_add_button(price, "Tiket -$5", func(): ticket_price = max(5, ticket_price - 5); _refresh_hud(); _show_finances())
	_add_button(price, "Tiket +$5", func(): ticket_price = min(100, ticket_price + 5); _refresh_hud(); _show_finances())
	var next := Button.new()
	next.text = "Akhiri hari dan rekap"
	next.pressed.connect(func(): _end_day())
	panel_box.add_child(next)

func _show_help() -> void:
	_clear_panel("Cara Bermain")
	for line in ["1. Mulai dengan uang $850.", "2. Bangun kandang lalu beli kapsul hewan.", "3. Klik peta untuk menempatkan objek.", "4. Pengunjung datang dan membayar tiket otomatis.", "5. Hewan lapar perlu diberi makan dari menu Koleksi.", "6. Upgrade kandang untuk menaikkan kualitas.", "7. Simpan progres sebelum keluar.", "Kontrol PC: WASD / tombol panah untuk menggeser kamera.", "Android: sentuh peta untuk membangun dan gunakan tombol menu."]:
		var l := Label.new()
		l.text = line
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		panel_box.add_child(l)

func _set_tool(tool: String) -> void:
	selected_tool = tool
	panel.visible = false
	_set_status("Pilih petak di peta untuk menempatkan: " + tool + ". Tekan tombol Bangun lagi untuk memilih alat lain.")

func _buy_egg(species: String, cost: int, ticks: int) -> void:
	if cash < cost:
		_set_status("Uang tidak cukup untuk membeli " + species + ".")
		return
	cash -= cost
	eggs.append({"species": species, "time": ticks})
	_set_status("Kapsul " + species + " dibeli. Akan menetas dalam " + str(ticks) + " tick game.")
	_refresh_hud()
	_show_animal_shop()

func _feed_animal(index: int) -> void:
	if index < 0 or index >= animals.size(): return
	if cash < 12:
		_set_status("Uang tidak cukup membeli pakan ($12).")
		return
	cash -= 12
	animals[index]["hunger"] = 100
	animals[index]["happiness"] = min(100, int(animals[index]["happiness"]) + 10)
	_set_status(str(animals[index]["species"]) + " sudah diberi makan.")
	_refresh_hud()
	_show_animals()

func _place_object(kind: String, cost: int, color: Color) -> void:
	if cash < cost:
		_set_status("Uang tidak cukup untuk " + kind + ".")
		return
	selected_tool = kind.to_lower().replace(" ", "_")
	_set_status("Klik petak kosong untuk menempatkan " + kind + ". Biaya $" + str(cost) + ".")
	panel.visible = false

func _expand_land() -> void:
	if cash < 350:
		_set_status("Butuh $350 untuk membuka lahan baru.")
		return
	cash -= 350
	reputation += 2
	objects.append({"kind":"expansion", "x": 1100, "y": 350, "color":"#6c9d55"})
	_set_status("Lahan diperluas! Reputasi meningkat.")
	_refresh_hud()
	queue_redraw()

func _hire_staff() -> void:
	if cash < 180:
		_set_status("Butuh $180 untuk merekrut staf.")
		return
	cash -= 180
	staff_count += 1
	_set_status("Staf direkrut. Mereka membantu operasional, tetapi ada biaya gaji.")
	_refresh_hud()

func _upgrade_selected() -> void:
	if cash < 250:
		_set_status("Butuh $250 untuk upgrade habitat.")
		return
	cash -= 250
	reputation += 2
	for a in animals:
		a["happiness"] = min(100, int(a.get("happiness", 80)) + 10)
	_set_status("Upgrade habitat berhasil! Reputasi dan kebahagiaan hewan meningkat.")
	_refresh_hud()

func _end_day() -> void:
	day += 1
	visitors_today = 0
	income_today = 0
	expense_today = 0
	_set_status("Hari baru dimulai. Pantau kebutuhan hewan dan biaya operasional.")
	_refresh_hud()
	_show_finances()

func _refresh_hud() -> void:
	if is_instance_valid(hud_label):
		hud_label.text = "  💰 $" + str(cash) + "     🐾 " + str(animals.size()) + " hewan     👥 " + str(visitors_today) + " pengunjung     ⭐ Reputasi " + str(reputation) + "     Hari " + str(day)

func _set_status(message: String) -> void:
	if is_instance_valid(status_label): status_label.text = message

func _draw() -> void:
	var view := get_viewport_rect().size
	var start_x := fposmod(cam_offset.x, TILE) - TILE
	var start_y := fposmod(cam_offset.y, TILE) - TILE
	for x in range(-1, int(view.x / TILE) + 2):
		for y in range(-1, int(view.y / TILE) + 2):
			var p := Vector2(start_x + x * TILE, start_y + y * TILE)
			var tile_x := int((p.x - cam_offset.x) / TILE)
			var tile_y := int((p.y - cam_offset.y) / TILE)
			var col := Color("#4d8a4c") if (tile_x + tile_y) % 3 != 0 else Color("#568f50")
			draw_rect(Rect2(p, Vector2(TILE, TILE)), col)
			draw_rect(Rect2(p, Vector2(TILE, TILE)), Color(0.1, 0.2, 0.1, 0.18), false, 1.0)
	# Main visitor paths
	_draw_path(Vector2(100, 300), Vector2(1000, 300))
	_draw_path(Vector2(400, 300), Vector2(400, 540))
	_draw_path(Vector2(760, 300), Vector2(760, 500))
	# Existing exhibits and placed objects
	_draw_enclosure(Rect2(250, 125, 250, 140), "KANDANG A")
	_draw_enclosure(Rect2(590, 125, 250, 140), "KANDANG B")
	_draw_gate(Vector2(100, 300))
	_draw_building(Vector2(45, 325), "ZOO", Color("#c69b62"))
	_draw_building(Vector2(870, 330), "TIKET", Color("#d98c45"))
	for obj in objects:
		var pos := Vector2(float(obj.get("x", 0)), float(obj.get("y", 0))) + cam_offset
		var kind := str(obj.get("kind", ""))
		match kind:
			"path": _draw_path(pos, pos + Vector2(TILE, 0))
			"fence": draw_rect(Rect2(pos, Vector2(TILE, 10)), Color("#9a7145"))
			"enclosure": _draw_enclosure(Rect2(pos, Vector2(160, 120)), "HABITAT")
			"bangku": _draw_bench(pos)
			"pohon": _draw_tree(pos)
			"tempat_sampah": draw_circle(pos, 10, Color("#8ba2a4"))
			"kios_makanan": _draw_building(pos, "KIOS", Color("#d98c45"))
			"expansion": draw_rect(Rect2(pos, Vector2(180, 150)), Color("#619b54"), false, 4)
	for i in range(animals.size()):
		var a: Dictionary = animals[i]
		var pos := Vector2(float(a.get("x", 0)), float(a.get("y", 0))) + cam_offset
		_draw_animal(pos, str(a.get("species", "Kelinci")))
	for i in range(min(14, visitors_today)):
		var px := 140.0 + float((i * 67) % 820)
		var py := 300.0 + sin(float(i) * 2.0) * 18.0
		_draw_person(Vector2(px, py) + cam_offset, i)

func _draw_path(a: Vector2, b: Vector2) -> void:
	var rect := Rect2(Vector2(min(a.x,b.x), min(a.y,b.y)), Vector2(max(1, abs(b.x-a.x)), max(1, abs(b.y-a.y))))
	if abs(b.x-a.x) > abs(b.y-a.y): rect.size.y = 34
	else: rect.size.x = 34
	draw_rect(rect, Color("#c7b38a"))
	draw_rect(rect, Color("#ddcba5"), false, 2)

func _draw_enclosure(rect: Rect2, title: String) -> void:
	draw_rect(rect, Color("#83a95c"))
	for x in range(int(rect.position.x), int(rect.end.x), 16):
		draw_rect(Rect2(x, rect.position.y, 12, 7), Color("#9d7147"))
		draw_rect(Rect2(x, rect.end.y-7, 12, 7), Color("#9d7147"))
	for y in range(int(rect.position.y), int(rect.end.y), 16):
		draw_rect(Rect2(rect.position.x, y, 7, 12), Color("#9d7147"))
		draw_rect(Rect2(rect.end.x-7, y, 7, 12), Color("#9d7147"))
	draw_string(ThemeDB.fallback_font, rect.position + Vector2(8, 20), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#183b24"))

func _draw_gate(pos: Vector2) -> void:
	draw_rect(Rect2(pos, Vector2(42, 12)), Color("#8a5c36"))
	draw_rect(Rect2(pos + Vector2(4, -4), Vector2(6, 20)), Color("#e0c08a"))
	draw_rect(Rect2(pos + Vector2(32, -4), Vector2(6, 20)), Color("#e0c08a"))

func _draw_building(pos: Vector2, label_text: String, color: Color) -> void:
	draw_rect(Rect2(pos, Vector2(78, 45)), color)
	draw_rect(Rect2(pos + Vector2(-5, -7), Vector2(88, 12)), Color("#704a37"))
	draw_rect(Rect2(pos + Vector2(8, 10), Vector2(17, 25)), Color("#6e9eaa"))
	draw_rect(Rect2(pos + Vector2(48, 10), Vector2(17, 25)), Color("#6e9eaa"))
	draw_string(ThemeDB.fallback_font, pos + Vector2(13, -11), label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)

func _draw_tree(pos: Vector2) -> void:
	draw_rect(Rect2(pos + Vector2(-3, 0), Vector2(7, 18)), Color("#76502e"))
	draw_texture_rect_region(BUILD_SHEET, Rect2(pos - Vector2(26, 36), Vector2(52, 58)), Rect2(535, 685, 75, 100), Color.WHITE, false, true)
	# fallback canopy underneath keeps the tree visible if the atlas crop is imperfect
	draw_circle(pos + Vector2(0, -3), 10, Color("#26703b"))

func _draw_bench(pos: Vector2) -> void:
	draw_rect(Rect2(pos, Vector2(30, 8)), Color("#a16b3d"))
	draw_rect(Rect2(pos + Vector2(2, 8), Vector2(4, 7)), Color("#5b412c"))
	draw_rect(Rect2(pos + Vector2(24, 8), Vector2(4, 7)), Color("#5b412c"))

func _draw_person(pos: Vector2, idx: int) -> void:
	# Reuse the user's top-down visitor sprite sheet for visible crowd sprites.
	var columns := [64, 86, 108, 151, 174, 196, 270, 292, 314]
	var source_x: int = columns[idx % columns.size()]
	draw_texture_rect_region(PEOPLE_SHEET, Rect2(pos - Vector2(9, 14), Vector2(18, 28)), Rect2(source_x, 66, 22, 34), Color.WHITE, false, true)

func _draw_animal(pos: Vector2, species: String) -> void:
	# Draw actual user-provided sprite-sheet crops where a suitable view exists.
	var source := Rect2(12, 38, 100, 78)
	match species:
		"Singa": source = Rect2(12, 38, 100, 78)
		"Harimau": source = Rect2(128, 45, 118, 72)
		"Kelinci": source = Rect2(22, 278, 66, 58)
		"Rusa": source = Rect2(675, 24, 84, 92)
		"Zebra": source = Rect2(1442, 24, 82, 94)
		"T-Rex": source = Rect2(8, 476, 145, 105)
	if species in ["Singa", "Harimau", "Kelinci", "Rusa", "Zebra", "T-Rex"]:
		draw_texture_rect_region(ANIMAL_SHEET, Rect2(pos - Vector2(26, 22), Vector2(52, 44)), source, Color.WHITE, false, true)
		return
	var body := Color("#bd8c4b")
	if species in ["Singa", "Harimau"]: body = Color("#d98d35")
	elif species == "Zebra": body = Color("#e6e2d7")
	elif species == "T-Rex": body = Color("#527d54")
	elif species == "Rusa": body = Color("#b98a56")
	_draw_ellipse(pos + Vector2(0, 2), Vector2(20, 12), Color(0,0,0,0.2))
	_draw_ellipse(pos, Vector2(18, 12), body)
	draw_circle(pos + Vector2(12, -4), 7, body.lightened(0.08))
	draw_circle(pos + Vector2(14, -5), 1.5, Color("#1b211b"))
	if species == "Harimau" or species == "Zebra":
		for s in [-7, 0, 7]: draw_line(pos + Vector2(s, -7), pos + Vector2(s-3, 5), Color("#292521"), 2)
	if species == "T-Rex":
		draw_line(pos + Vector2(-12, 4), pos + Vector2(-23, 10), body, 5)

func _draw_ellipse(center: Vector2, size: Vector2, color: Color) -> void:
	draw_set_transform(center)
	draw_colored_polygon(PackedVector2Array([Vector2(-size.x,0),Vector2(-size.x*0.7,-size.y*0.7),Vector2(0,-size.y),Vector2(size.x*0.7,-size.y*0.7),Vector2(size.x,0),Vector2(size.x*0.7,size.y*0.7),Vector2(0,size.y),Vector2(-size.x*0.7,size.y*0.7)]), color)
	draw_set_transform(Vector2.ZERO)

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_world_click(event.position)
	elif event is InputEventScreenTouch and event.pressed:
		_handle_world_click(event.position)

func _handle_world_click(screen_pos: Vector2) -> void:
	if screen_pos.y < 80 or screen_pos.y > 610 or screen_pos.x > 890: return
	var world := screen_pos - cam_offset
	var snapped := Vector2(round(world.x / TILE) * TILE, round(world.y / TILE) * TILE)
	match selected_tool:
		"path":
			if cash >= 8:
				cash -= 8; objects.append({"kind":"path", "x":snapped.x, "y":snapped.y}); _set_status("Jalan berhasil dibangun."); selected_tool = "select"
			else: _set_status("Uang tidak cukup.")
		"fence":
			if cash >= 18:
				cash -= 18; objects.append({"kind":"fence", "x":snapped.x, "y":snapped.y}); _set_status("Pagar berhasil dipasang."); selected_tool = "select"
			else: _set_status("Uang tidak cukup.")
		"enclosure":
			if cash >= 120:
				cash -= 120; objects.append({"kind":"enclosure", "x":snapped.x, "y":snapped.y}); _set_status("Kandang baru berhasil dibangun."); selected_tool = "select"
			else: _set_status("Uang tidak cukup.")
		"bangku", "pohon", "tempat_sampah", "kios_makanan":
			var cost := 45 if selected_tool == "bangku" else (35 if selected_tool == "pohon" else (30 if selected_tool == "tempat_sampah" else 180))
			if cash >= cost:
				cash -= cost; objects.append({"kind":selected_tool, "x":snapped.x, "y":snapped.y}); _set_status("Objek berhasil ditempatkan."); selected_tool = "select"
			else: _set_status("Uang tidak cukup.")
		_:
			_set_status("Pilih Bangun untuk memilih objek, atau gunakan menu Toko Hewan.")
	_refresh_hud()
	queue_redraw()

func _save_game() -> void:
	var data := {"cash":cash,"reputation":reputation,"ticket_price":ticket_price,"day":day,"visitors_today":visitors_today,"total_visitors":total_visitors,"income_today":income_today,"expense_today":expense_today,"animals":animals,"objects":objects,"eggs":eggs,"staff_count":staff_count}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		_set_status("Game berhasil disimpan di perangkat.")
	else:
		_set_status("Gagal menyimpan game.")

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file: return
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY: return
	cash = int(parsed.get("cash", cash)); reputation = int(parsed.get("reputation", reputation)); ticket_price = int(parsed.get("ticket_price", ticket_price)); day = int(parsed.get("day", day)); visitors_today = int(parsed.get("visitors_today", 0)); total_visitors = int(parsed.get("total_visitors", 0)); income_today = int(parsed.get("income_today", 0)); expense_today = int(parsed.get("expense_today", 0)); staff_count = int(parsed.get("staff_count", 0))
	animals.assign(parsed.get("animals", [])); objects.assign(parsed.get("objects", [])); eggs.assign(parsed.get("eggs", []))
