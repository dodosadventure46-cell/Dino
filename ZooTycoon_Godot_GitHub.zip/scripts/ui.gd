extends CanvasLayer
# All UI is built from code (no fragile .tscn dependencies).

const Z = preload("res://scripts/data.gd")

var g
var th
var root
var hud
var menu_root
var panel
var panel_title
var body
var panel_name = ""
var live = []
var live_t = 0.0
var lbl_cash
var lbl_day
var lbl_rep
var lbl_vis
var lbl_ticket
var lbl_speed
var toast_label
var toast_t = 0.0
var goal_label
var buildbar
var build_label
var btn_ok
var joy
var btn_continue


class Joy extends Control:
	var vec = Vector2.ZERO
	var active = false
	var center = Vector2(80, 80)

	func _init():
		mouse_filter = Control.MOUSE_FILTER_STOP

	func _gui_input(ev):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			active = ev.pressed
			if ev.pressed:
				upd(ev.position)
			else:
				vec = Vector2.ZERO
				queue_redraw()
		elif ev is InputEventMouseMotion and active:
			upd(ev.position)

	func upd(p):
		var d = p - center
		if d.length() > 70.0:
			d = d.normalized() * 70.0
		vec = d / 70.0
		queue_redraw()

	func _draw():
		draw_circle(center, 70.0, Color(1, 1, 1, 0.12))
		draw_circle(center + vec * 70.0, 28.0, Color(1, 1, 1, 0.38))


# ---------------------------------------------------------------- helpers
func anchor(c, l, t, r, b, ol = 0, ot = 0, orr = 0, ob = 0):
	c.anchor_left = l
	c.anchor_top = t
	c.anchor_right = r
	c.anchor_bottom = b
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = orr
	c.offset_bottom = ob


func lab(text = "", size = 0):
	var l = Label.new()
	l.text = text
	if size > 0:
		l.add_theme_font_size_override("font_size", size)
	return l


func btn(text, cb, minw = 0, minh = 48):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(minw, minh)
	b.pressed.connect(cb)
	return b


func icon(texture, sz = 40):
	var r = TextureRect.new()
	r.texture = texture
	r.custom_minimum_size = Vector2(sz, sz)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	return r


func row():
	var r = HBoxContainer.new()
	r.add_theme_constant_override("separation", 10)
	body.add_child(r)
	return r


func wrap_label(text, minw = 300):
	var l = lab(text)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.x = minw
	return l


func confirm(text, cb):
	var d = ConfirmationDialog.new()
	d.dialog_text = text
	d.ok_button_text = "Ya"
	d.cancel_button_text = "Batal"
	d.theme = th
	d.confirmed.connect(cb)
	d.confirmed.connect(d.queue_free)
	d.canceled.connect(d.queue_free)
	add_child(d)
	d.popup_centered()


# ---------------------------------------------------------------- setup
func setup(game):
	g = game
	layer = 10
	th = Theme.new()
	th.default_font_size = 20
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.15, 0.1, 0.96)
	sb.border_color = Color(0.95, 0.8, 0.3)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(8)
	th.set_stylebox("panel", "PanelContainer", sb)
	root = Control.new()
	root.theme = th
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	anchor(root, 0, 0, 1, 1)
	add_child(root)
	build_hud()
	build_menu()
	build_panel()
	toast_label = Label.new()
	toast_label.add_theme_font_size_override("font_size", 22)
	toast_label.add_theme_color_override("font_outline_color", Color.BLACK)
	toast_label.add_theme_constant_override("outline_size", 6)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	anchor(toast_label, 0.1, 0, 0.9, 0, 0, 100, 0, 140)
	toast_label.visible = false
	root.add_child(toast_label)


func build_hud():
	hud = Control.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	anchor(hud, 0, 0, 1, 1)
	root.add_child(hud)
	# top bar
	var top = PanelContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_STOP
	anchor(top, 0, 0, 1, 0, 0, 0, 0, 56)
	hud.add_child(top)
	var hb = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	top.add_child(hb)
	lbl_cash = lab("")
	lbl_day = lab("")
	lbl_rep = lab("")
	lbl_vis = lab("")
	lbl_ticket = lab("")
	for l in [lbl_cash, lbl_day, lbl_rep, lbl_vis]:
		hb.add_child(l)
	hb.add_child(lbl_ticket)
	hb.add_child(btn("-", func(): ticket_mul(0.85), 44, 40))
	hb.add_child(btn("+", func(): ticket_mul(1.18), 44, 40))
	hb.add_child(btn("Auto", func(): ticket_auto(), 70, 40))
	lbl_speed = lab("")
	hb.add_child(btn("II", func(): g.paused = not g.paused, 44, 40))
	hb.add_child(btn("1x", func(): set_speed(1.0), 44, 40))
	hb.add_child(btn("2x", func(): set_speed(2.0), 44, 40))
	hb.add_child(btn("3x", func(): set_speed(3.0), 44, 40))
	# goal / hint
	var gp = PanelContainer.new()
	gp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	anchor(gp, 0, 0, 0.62, 0, 8, 62, 0, 100)
	hud.add_child(gp)
	goal_label = lab("")
	goal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_label.add_theme_font_size_override("font_size", 17)
	goal_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gp.add_child(goal_label)
	# bottom bar
	var bot = PanelContainer.new()
	bot.mouse_filter = Control.MOUSE_FILTER_STOP
	anchor(bot, 0, 1, 1, 1, 0, -64, 0, 0)
	hud.add_child(bot)
	var bb = HBoxContainer.new()
	bb.add_theme_constant_override("separation", 6)
	bot.add_child(bb)
	for p in [["Bangun", "build"], ["Toko", "shop"], ["Hewan", "animals"], ["Staf", "staff"], ["Riset", "research"], ["Uang", "finance"], ["Menu", "menu"]]:
		var b = btn(p[0], open.bind(p[1]), 0, 52)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bb.add_child(b)
	bb.add_child(btn("+", func(): g.set_zoom(g.cam.zoom.x * 1.2), 52, 52))
	bb.add_child(btn("-", func(): g.set_zoom(g.cam.zoom.x / 1.2), 52, 52))
	# build bar
	buildbar = PanelContainer.new()
	buildbar.mouse_filter = Control.MOUSE_FILTER_STOP
	anchor(buildbar, 0.15, 1, 0.85, 1, 0, -130, 0, -70)
	hud.add_child(buildbar)
	var bh = HBoxContainer.new()
	bh.add_theme_constant_override("separation", 10)
	buildbar.add_child(bh)
	build_label = lab("")
	build_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bh.add_child(build_label)
	btn_ok = btn("OK", func(): g.place_current(), 80, 48)
	bh.add_child(btn_ok)
	bh.add_child(btn("Putar", func(): g.rot = 1 - g.rot, 90, 48))
	bh.add_child(btn("Batal", func(): g.cancel_tool(), 90, 48))
	buildbar.visible = false
	# joystick
	joy = Joy.new()
	anchor(joy, 0, 1, 0, 1, 16, -260, 176, -100)
	hud.add_child(joy)
	hud.visible = false


func build_menu():
	menu_root = Control.new()
	menu_root.mouse_filter = Control.MOUSE_FILTER_STOP
	anchor(menu_root, 0, 0, 1, 1)
	root.add_child(menu_root)
	var bg = ColorRect.new()
	bg.color = Color(0.05, 0.12, 0.06, 0.88)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	anchor(bg, 0, 0, 1, 1)
	menu_root.add_child(bg)
	var cc = CenterContainer.new()
	anchor(cc, 0, 0, 1, 1)
	menu_root.add_child(cc)
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)
	var t1 = lab("ZOO TYCOON", 56)
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t1.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	vb.add_child(t1)
	var t2 = lab("FROM BROKE TO BILLIONAIRE", 26)
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t2)
	vb.add_child(btn("Game Baru", func(): g.start_new(), 360, 60))
	btn_continue = btn("Lanjutkan", func(): g.start_continue(), 360, 60)
	vb.add_child(btn_continue)
	vb.add_child(btn("Pengaturan", func(): open("settings"), 360, 60))
	vb.add_child(btn("Keluar", func(): get_tree().quit(), 360, 60))
	menu_root.visible = false


func build_panel():
	panel = PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	anchor(panel, 0.05, 0.15, 0.95, 0.80)
	root.add_child(panel)
	var vb = VBoxContainer.new()
	panel.add_child(vb)
	var hb = HBoxContainer.new()
	vb.add_child(hb)
	panel_title = lab("", 26)
	panel_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel_title.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	hb.add_child(panel_title)
	hb.add_child(btn("Tutup", func(): close_panel(), 100, 44))
	vb.add_child(HSeparator.new())
	var sc = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 8)
	sc.add_child(body)
	panel.visible = false


# ---------------------------------------------------------------- state switches
func show_menu():
	hud.visible = false
	menu_root.visible = true
	panel.visible = false
	panel_name = ""
	btn_continue.disabled = not g.has_save()


func show_hud():
	menu_root.visible = false
	hud.visible = true
	panel.visible = false
	panel_name = ""
	joy.visible = g.settings.touch
	on_tool_changed()
	hud_update()


func show_win():
	confirm("SELAMAT! Kamu telah menjadi MILIARDER dan pemilik kebun binatang terkaya di dunia!\nTekan Ya untuk terus bermain.", func(): pass)


func toast(text, bad = false):
	if toast_label == null:
		return
	toast_label.text = text
	toast_label.add_theme_color_override("font_color", Color(1, 0.5, 0.45) if bad else Color(0.7, 1, 0.7))
	toast_label.visible = true
	toast_t = 3.0


func joy_vec():
	if joy != null and joy.visible:
		return joy.vec
	return Vector2.ZERO


func panel_open():
	return panel.visible


func close_panel():
	panel.visible = false
	panel_name = ""


func open(name):
	if name == "menu" and g.state != "play":
		return
	panel_name = name
	panel.visible = true
	g.sfx("click")
	refresh()


func on_tool_changed():
	if buildbar == null:
		return
	buildbar.visible = g.tool != "select"
	btn_ok.visible = g.is_touch
	if g.tool != "select" and Z.OBJ.has(g.tool):
		build_label.text = "%s  %s" % [Z.OBJ[g.tool].n, Z.money(g.obj_cost(g.tool)) if g.moving == null else "(memindahkan)"]
		if g.tool == "path":
			build_label.text += "  - seret untuk menggambar jalan"
	if panel.visible and panel_name == "build":
		close_panel()


func on_change():
	if panel.visible:
		refresh()
	hud_update()


func ticket_mul(m):
	var n = g.ticket * m
	if absf(n - g.ticket) < 1.0:
		n = g.ticket + (1.0 if m > 1.0 else -1.0)
	g.ticket = clampf(float(int(n)), 1.0, 1.0e9)
	hud_update()


func ticket_auto():
	g.ticket = maxf(1.0, float(int(g.willingness() * 0.9)))
	hud_update()


func set_speed(s):
	g.speed = s
	g.paused = false
	hud_update()


func hud_update():
	if lbl_cash == null or g == null:
		return
	lbl_cash.text = "Kas: " + Z.money(g.cash)
	lbl_day.text = "Hari %d%s" % [g.day, " (JEDA)" if g.paused else " x%d" % int(g.speed)]
	lbl_rep.text = "Reputasi: %d" % int(g.rep)
	lbl_vis.text = "Pengunjung: %d/%d" % [g.visitors.size(), g.visitor_cap()]
	lbl_ticket.text = "Tiket: " + Z.money(g.ticket)
	goal_label.text = g.hint


func _process(delta):
	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0:
			toast_label.visible = false
	live_t -= delta
	if live_t <= 0.0:
		live_t = 0.25
		if g.state == "play":
			hud_update()
		update_live()


# ---------------------------------------------------------------- panels
func refresh():
	live = []
	for c in body.get_children():
		body.remove_child(c)
		c.queue_free()
	match panel_name:
		"build":
			panel_title.text = "Bangun"
			build_build()
		"shop":
			panel_title.text = "Toko Hewan & Inkubator"
			build_shop()
		"animals":
			panel_title.text = "Manajemen Hewan"
			build_animals()
		"animal_detail":
			panel_title.text = "Detail Hewan"
			build_animal_detail()
		"obj":
			panel_title.text = "Objek"
			build_obj()
		"staff":
			panel_title.text = "Staf"
			build_staff()
		"research":
			panel_title.text = "Riset"
			build_research()
		"finance":
			panel_title.text = "Dashboard Keuangan"
			build_finance()
		"menu":
			panel_title.text = "Menu Jeda"
			build_menu_panel()
		"settings":
			panel_title.text = "Pengaturan"
			build_settings()
	update_live()


func update_live():
	if not panel.visible:
		return
	for e in live:
		match e.k:
			"incub":
				var it = e.it
				e.pb.value = 1.0 - it.t / it.total
				e.tl.text = Z.fmt_secs(it.t)
				e.b.disabled = it.t > 0.0
			"text":
				e.n.text = call(e.f)
			"alabel":
				e.n.text = "%s\n%s" % [e.a.name, animal_line(e.a)]


func build_build():
	body.add_child(wrap_label("Pilih alat lalu tap/klik di peta. Desktop: klik langsung membangun. HP: tap untuk menaruh bayangan, tekan OK. Gunakan joystick/WASD untuk berjalan, seret layar untuk menggeser kamera."))
	for t in Z.BUILD_ORDER:
		var d = Z.OBJ[t]
		var r = row()
		var txt = "%s - %s" % [d.n, Z.money(g.obj_cost(t))]
		if t == "enc":
			txt += "  (6x6 petak, pagar otomatis; jalan harus menempel di pagar)"
		elif t == "path":
			txt += "  (per petak)"
		r.add_child(wrap_label(txt))
		r.add_child(btn("Pilih", g.set_tool.bind(t), 120))
	var r2 = row()
	r2.add_child(wrap_label("Beli tanah (+2 petak kiri/kanan/atas): " + Z.money(g.expand_cost())))
	r2.add_child(btn("Beli", g.buy_land, 120))
	var r3 = row()
	r3.add_child(wrap_label("Pilih/inspeksi objek atau hewan: kembali ke mode Pilih lalu tap objek di peta."))
	r3.add_child(btn("Mode Pilih", g.set_tool.bind("select"), 160))


func build_shop():
	body.add_child(lab("Inkubator (%d/%d slot terpakai)" % [g.incub.size(), g.slot_count()]))
	for i in range(g.slot_count()):
		var r = row()
		if i < g.incub.size():
			var it = g.incub[i]
			var sp = Z.SPECIES[it.sp]
			r.add_child(icon(g.tex("res://assets/props/%s.png" % ("capsule" if sp.kind == "caps" else ("dino_egg" if sp.kind == "dino" else "egg")))))
			var l = lab("%s (%s)" % [sp.n, Z.KIND_NAMES[sp.kind]])
			l.custom_minimum_size.x = 260
			r.add_child(l)
			var pb = ProgressBar.new()
			pb.custom_minimum_size = Vector2(200, 28)
			pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			pb.max_value = 1.0
			pb.show_percentage = false
			r.add_child(pb)
			var tl = lab("")
			tl.custom_minimum_size.x = 60
			r.add_child(tl)
			var b = btn("Tetas!", g.hatch.bind(it), 110)
			r.add_child(b)
			live.append({"k": "incub", "it": it, "pb": pb, "tl": tl, "b": b})
		else:
			r.add_child(lab("Slot %d kosong" % (i + 1)))
	body.add_child(HSeparator.new())
	body.add_child(lab("Katalog (mamalia memakai Kapsul Genetik fiktif)"))
	for id in Z.ORDER:
		var sp = Z.SPECIES[id]
		var lock = g.species_lock(id)
		var r = row()
		r.add_child(icon(g.sp_tex(id)))
		var l = wrap_label("%s [%s] - %s\nInkubasi %ds | Kandang min. Tier %d | Daya tarik %d | Biaya %s/hari" % [sp.n, Z.RARITY_NAMES[sp.r], Z.KIND_NAMES[sp.kind], sp.inc, sp.tier, sp.attr, Z.money(maxf(1.0, sp.p * 0.004))], 260)
		l.add_theme_color_override("font_color", Z.RARITY_COLORS[sp.r])
		r.add_child(l)
		var b = btn("Beli " + Z.money(sp.p), g.buy_egg.bind(id), 190)
		if lock != "":
			b.text = lock
			b.disabled = true
		r.add_child(b)


func animal_line(a):
	return "Lapar: %d%% kenyang | Senang: %d%% | Sehat: %d%%" % [int(a.sat), int(a.hap), int(a.health)]


func animal_line_live(a):
	return animal_line(a)


func build_animals():
	if g.animals.is_empty():
		body.add_child(wrap_label("Belum ada hewan. Beli telur di Toko dan tetaskan."))
		return
	var tot = 0.0
	for a in g.animals:
		tot += g.food_cost(a)
	var r0 = row()
	r0.add_child(wrap_label("Total hewan: %d" % g.animals.size()))
	r0.add_child(btn("Beri Makan Semua (~%s)" % Z.money(tot), g.feed_all, 300))
	for a in g.animals:
		var r = row()
		r.add_child(icon(g.sp_tex(a.sp)))
		var l = wrap_label("")
		var key = "al_%d" % a.id
		l.text = "%s\n%s" % [a.name, animal_line(a)]
		r.add_child(l)
		live.append({"k": "alabel", "n": l, "a": a})
		r.add_child(btn("Detail", open_animal.bind(a), 110))


func open_animal(a):
	g.selected_animal = a
	open("animal_detail")


func detail_text():
	var a = g.selected_animal
	if a == null or not g.animals.has(a):
		return "-"
	var sp = Z.SPECIES[a.sp]
	var e = g.enc_by_id.get(a.enc)
	var tier = 1
	if e:
		tier = e.tier
	var est = g.animal_attr(a) * 0.05 * maxf(10.0, g.last_day.visitors)
	var stage = "Bayi" if a.age < 1.0 else ("Remaja" if a.age < 3.0 else "Dewasa")
	return "%s | %s | %s\nUmur: %.1f hari (%s)\nKenyang: %d%%  Senang: %d%%  Sehat: %d%%\nKandang: Tier %d  |  Daya tarik: %d\nPerkiraan kontribusi pendapatan/hari: %s\nBiaya pemeliharaan/hari: %s  |  Biaya pakan: %s" % [
		sp.n, Z.RARITY_NAMES[sp.r], Z.KIND_NAMES[sp.kind], a.age, stage, int(a.sat), int(a.hap), int(a.health), tier,
		int(g.animal_attr(a)), Z.money(est), Z.money(g.animal_upkeep(a)), Z.money(g.food_cost(a))]


func build_animal_detail():
	var a = g.selected_animal
	if a == null or not g.animals.has(a):
		panel_name = "animals"
		panel_title.text = "Manajemen Hewan"
		build_animals()
		return
	var r = row()
	r.add_child(icon(g.sp_tex(a.sp), 72))
	var le = LineEdit.new()
	le.text = a.name
	le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	le.custom_minimum_size = Vector2(240, 48)
	r.add_child(le)
	r.add_child(btn("Ganti Nama", rename_animal.bind(a, le), 150))
	var l = wrap_label("")
	body.add_child(l)
	live.append({"k": "text", "n": l, "f": "detail_text"})
	var r2 = row()
	r2.add_child(btn("Beri Makan", feed_sel.bind(a), 150))
	r2.add_child(btn("Pindah Kandang", g.move_animal.bind(a), 190))
	r2.add_child(btn("Jual (50%)", ask_sell.bind(a), 150))
	var r3 = row()
	r3.add_child(btn("Fokus Kamera", focus_animal.bind(a), 170))
	r3.add_child(btn("Kembali", back_animals, 120))


func rename_animal(a, le):
	a.name = le.text.substr(0, 24)
	g.sfx("click")


func feed_sel(a):
	g.feed(a)
	update_live()


func ask_sell(a):
	confirm("Jual %s seharga %s?" % [a.name, Z.money(Z.SPECIES[a.sp].p * 0.5)], sell_now.bind(a))


func sell_now(a):
	g.sell_animal(a)
	open("animals")


func focus_animal(a):
	g.focus_on(Vector2(a.px, a.py))
	close_panel()


func back_animals():
	g.selected_animal = null
	open("animals")


func obj_text():
	var o = g.selected_obj
	if o == null or not g.objs.has(o):
		return "-"
	var d = Z.OBJ[o.type]
	var t = d.n
	if o.type == "enc":
		var sp_name = "Kosong"
		for a in g.animals:
			if a.enc == o.id:
				sp_name = Z.SPECIES[a.sp].n
				break
		t += "\nTier %d (%s) | Hewan: %s %d/%d\nPengayaan sekitar: +%d kebahagiaan | Pagar: tier lebih tinggi = risiko kabur lebih kecil" % [
			o.tier, Z.TIER_NAMES[o.tier], sp_name, g.enc_count(o), Z.TIER_CAP[o.tier], int(o.enrich)]
	return t


func build_obj():
	var o = g.selected_obj
	if o == null or not g.objs.has(o):
		body.add_child(lab("Tidak ada objek terpilih."))
		return
	var l = wrap_label("")
	body.add_child(l)
	live.append({"k": "text", "n": l, "f": "obj_text"})
	if o.type == "enc":
		var r = row()
		if o.tier < 5:
			var blk = g.upgrade_block(o)
			var b = btn("Upgrade ke Tier %d (%s)" % [o.tier + 1, Z.money(g.upgrade_cost(o))], g.upgrade_enc.bind(o), 330)
			r.add_child(b)
			if blk != "":
				r.add_child(wrap_label(blk, 150))
		else:
			r.add_child(lab("Tier maksimal"))
	var r2 = row()
	if o.type != "gate":
		r2.add_child(btn("Pindahkan", g.start_move.bind(o), 150))
		r2.add_child(btn("Hapus (refund 50%)", ask_remove.bind(o), 230))
	else:
		r2.add_child(lab("Pintu masuk tidak dapat dipindah/dihapus."))


func ask_remove(o):
	confirm("Hapus %s?" % Z.OBJ[o.type].n, g.remove_obj.bind(o))


func reload_now():
	g.start_continue()
	close_panel()


func build_staff():
	for role in Z.STAFF_ORDER:
		var d = Z.STAFF[role]
		var r = row()
		var n = g.staff_n.get(role, 0)
		r.add_child(wrap_label("%s (%d)\n%s\nRekrut %s | Gaji %s/hari" % [d.n, n, d.d, Z.money(d.hire), Z.money(d.sal * g.staff_mult())], 320))
		var b = btn("Rekrut", g.hire.bind(role), 110)
		if g.staff_locked(role):
			b.text = "Terkunci"
			b.disabled = true
		r.add_child(b)
		var f = btn("Pecat", g.fire.bind(role), 100)
		f.disabled = n <= 0
		r.add_child(f)


func build_research():
	for r in Z.RESEARCH:
		var row_ = row()
		var done = g.research.has(r.id)
		var txt = "%s\n%s\nBiaya %s | Reputasi %d" % [r.n, r.d, Z.money(r.cost), r.rep]
		if r.req != "":
			for q in Z.RESEARCH:
				if q.id == r.req:
					txt += " | Butuh: " + q.n
		var l = wrap_label(txt, 320)
		if done:
			l.add_theme_color_override("font_color", Color(0.6, 1, 0.6))
		row_.add_child(l)
		var b = btn("Riset", g.do_research.bind(r), 120)
		if done:
			b.text = "Selesai"
			b.disabled = true
		elif g.rep < r.rep or (r.req != "" and not g.research.has(r.req)):
			b.disabled = true
		row_.add_child(b)


func fin_text():
	var t = g.today
	var l = g.last_day
	var s = g.stats
	var out = "Kas: %s | Kekayaan bersih: %s\nPendapatan total: %s | Biaya total: %s | Laba bersih: %s\n" % [
		Z.money(g.cash), Z.money(g.net_worth), Z.money(s.total_rev), Z.money(s.total_exp), Z.money(s.total_rev - s.total_exp)]
	out += "Pengunjung total: %d | Hari ini: %d | Reputasi: %.1f | Kepuasan rata-rata: %d%%\n" % [s.total_visitors, t.visitors, g.rep, int(s.sat_avg)]
	out += "Kebersihan: %d%% | Daya tarik total: %d | Tiket maks. yang diterima: %s | Tiket saat ini: %s\n\n" % [int(g.clean), int(g.total_attr), Z.money(g.willingness() * 1.15), Z.money(g.ticket)]
	out += "HARI INI: pendapatan %s (tiket %s, kios %s) | biaya %s (hewan/fasilitas %s, gaji %s, pakan %s, pembangunan %s)\n" % [
		Z.money(t.rev), Z.money(t.ticket), Z.money(t.shop), Z.money(t.exp), Z.money(t.upkeep), Z.money(t.salary), Z.money(t.food), Z.money(t.build)]
	out += "KEMARIN: pendapatan %s | biaya %s | laba %s\n\n" % [Z.money(l.rev), Z.money(l.exp), Z.money(l.rev - l.exp)]
	out += "Tujuan: " + g.next_goal_text()
	return out


func build_finance():
	var l = wrap_label("")
	body.add_child(l)
	live.append({"k": "text", "n": l, "f": "fin_text"})
	body.add_child(lab("Tujuan Kekayaan:"))
	for goal in Z.GOALS:
		var ok = g.net_worth >= goal.v
		var gl = lab(("[x] " if ok else "[ ] ") + goal.n)
		if ok:
			gl.add_theme_color_override("font_color", Color(0.6, 1, 0.6))
		body.add_child(gl)


func build_menu_panel():
	body.add_child(btn("Lanjutkan", close_panel, 0, 56))
	body.add_child(btn("Simpan", g.save_game, 0, 56))
	body.add_child(btn("Muat Simpanan", ask_reload, 0, 56))
	body.add_child(btn("Pengaturan", open.bind("settings"), 0, 56))
	body.add_child(btn("Simpan & Kembali ke Menu Utama", save_menu, 0, 56))


func ask_reload():
	confirm("Muat simpanan terakhir? Progres yang belum disimpan akan hilang.", reload_now)


func save_menu():
	close_panel()
	g.save_and_menu()


func set_opt(v, key):
	g.settings[key] = v
	if key == "touch":
		joy.visible = v and g.state == "play"
	g.save_settings()


func set_fps(n):
	g.settings.fps = n
	g.apply_settings()
	g.save_settings()


func build_settings():
	var r1 = row()
	var cb = CheckButton.new()
	cb.text = "Suara"
	cb.button_pressed = g.settings.sfx
	cb.toggled.connect(set_opt.bind("sfx"))
	r1.add_child(cb)
	var sl = HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = g.settings.vol
	sl.custom_minimum_size = Vector2(240, 40)
	sl.value_changed.connect(set_opt.bind("vol"))
	r1.add_child(sl)
	var r2 = row()
	r2.add_child(lab("Target FPS:"))
	r2.add_child(btn("30", set_fps.bind(30), 80))
	r2.add_child(btn("60", set_fps.bind(60), 80))
	var r3 = row()
	var c2 = CheckButton.new()
	c2.text = "Kualitas rendah (pengunjung lebih sedikit, lebih ringan)"
	c2.button_pressed = g.settings.low
	c2.toggled.connect(set_opt.bind("low"))
	r3.add_child(c2)
	var r4 = row()
	var c3 = CheckButton.new()
	c3.text = "Joystick layar sentuh"
	c3.button_pressed = g.settings.touch
	c3.toggled.connect(set_opt.bind("touch"))
	r4.add_child(c3)
	body.add_child(wrap_label("Kontrol: WASD/panah atau joystick = berjalan. Klik kanan/seret = geser kamera. Roda mouse/tombol +/- = zoom. R = putar. B = bangun. Spasi = jeda. Esc = batal/menu."))
