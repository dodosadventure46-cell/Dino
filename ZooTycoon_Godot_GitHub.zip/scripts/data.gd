extends RefCounted
# Static game data. Use via: const Z = preload("res://scripts/data.gd")

const T = 32
const WORLD_W = 60
const WORLD_H = 44
const DAY_LEN = 60.0
const VERSION = 1
const GATE = Vector2i(29, 34)
const START_LAND = Rect2i(22, 23, 16, 12)

const RARITY_NAMES = ["Umum", "Tidak Umum", "Langka", "Epik", "Legendaris"]
const RARITY_COLORS = [Color(0.85, 0.85, 0.85), Color(0.45, 0.95, 0.45), Color(0.45, 0.65, 1.0), Color(0.8, 0.45, 1.0), Color(1.0, 0.78, 0.25)]
const RARITY_RES = ["", "r_unc", "r_rare", "r_epic", "r_leg"]

const TIER_NAMES = ["", "Dasar", "Ditingkatkan", "Premium", "Maju", "Mewah"]
const TIER_CAP = [0, 2, 3, 4, 5, 6]
const TIER_COST = [0, 0, 300, 1500, 12000, 120000]
const TIER_RES = ["", "", "", "r_t3", "r_t4", "r_t5"]
const TIER_FENCE = [Color.WHITE, Color(0.8, 0.6, 0.4), Color(0.85, 0.88, 0.92), Color(0.55, 0.8, 1.0), Color(0.75, 0.55, 1.0), Color(1.0, 0.85, 0.3)]
const TIER_GROUND = [Color.WHITE, Color(1, 1, 1), Color(0.9, 1.0, 0.9), Color(0.85, 1.0, 1.0), Color(1.0, 0.95, 0.8), Color(1.0, 0.9, 0.6)]

const KIND_NAMES = {"egg": "Telur", "caps": "Kapsul Genetik", "dino": "Telur Dino"}

const ORDER = ["ayam", "kelinci", "kura", "rusa", "zebra", "unta", "singa", "harimau", "beruang", "gajah",
	"raptor", "stego", "trike", "trex", "brachio", "spino"]

# n=name r=rarity p=price inc=incubation seconds attr=visitor appeal tier=min enclosure tier rep=min reputation
const SPECIES = {
	"ayam": {"n": "Ayam", "r": 0, "p": 40, "inc": 15, "attr": 4, "tier": 1, "kind": "egg", "rep": 0, "dir": "animals"},
	"kelinci": {"n": "Kelinci", "r": 0, "p": 90, "inc": 20, "attr": 8, "tier": 1, "kind": "caps", "rep": 0, "dir": "animals"},
	"kura": {"n": "Kura-kura", "r": 0, "p": 160, "inc": 25, "attr": 14, "tier": 1, "kind": "egg", "rep": 0, "dir": "animals"},
	"rusa": {"n": "Rusa", "r": 1, "p": 600, "inc": 40, "attr": 40, "tier": 1, "kind": "caps", "rep": 3, "dir": "animals"},
	"zebra": {"n": "Zebra", "r": 1, "p": 1200, "inc": 55, "attr": 80, "tier": 1, "kind": "caps", "rep": 4, "dir": "animals"},
	"unta": {"n": "Burung Unta", "r": 1, "p": 2000, "inc": 60, "attr": 130, "tier": 1, "kind": "egg", "rep": 5, "dir": "animals"},
	"singa": {"n": "Singa", "r": 2, "p": 8000, "inc": 90, "attr": 450, "tier": 2, "kind": "caps", "rep": 8, "dir": "animals"},
	"harimau": {"n": "Harimau", "r": 2, "p": 14000, "inc": 100, "attr": 800, "tier": 2, "kind": "caps", "rep": 10, "dir": "animals"},
	"beruang": {"n": "Beruang", "r": 2, "p": 25000, "inc": 110, "attr": 1300, "tier": 2, "kind": "caps", "rep": 12, "dir": "animals"},
	"gajah": {"n": "Gajah", "r": 2, "p": 60000, "inc": 130, "attr": 3000, "tier": 2, "kind": "caps", "rep": 15, "dir": "animals"},
	"raptor": {"n": "Velociraptor", "r": 3, "p": 250000, "inc": 160, "attr": 12000, "tier": 3, "kind": "dino", "rep": 25, "dir": "dinosaurs"},
	"stego": {"n": "Stegosaurus", "r": 3, "p": 700000, "inc": 180, "attr": 32000, "tier": 3, "kind": "dino", "rep": 30, "dir": "dinosaurs"},
	"trike": {"n": "Triceratops", "r": 3, "p": 2000000, "inc": 200, "attr": 90000, "tier": 3, "kind": "dino", "rep": 35, "dir": "dinosaurs"},
	"trex": {"n": "T-Rex", "r": 4, "p": 8000000, "inc": 240, "attr": 380000, "tier": 4, "kind": "dino", "rep": 45, "dir": "dinosaurs"},
	"brachio": {"n": "Brachiosaurus", "r": 4, "p": 40000000, "inc": 270, "attr": 1800000, "tier": 4, "kind": "dino", "rep": 55, "dir": "dinosaurs"},
	"spino": {"n": "Spinosaurus", "r": 4, "p": 150000000, "inc": 300, "attr": 7000000, "tier": 5, "kind": "dino", "rep": 65, "dir": "dinosaurs"},
}

# placeable objects: w/h in tiles, solid = blocks the player
const OBJ = {
	"path": {"n": "Jalan", "cost": 5, "w": 1, "h": 1, "solid": false},
	"enc": {"n": "Kandang", "cost": 200, "w": 6, "h": 6, "solid": true},
	"bench": {"n": "Bangku", "cost": 40, "w": 1, "h": 1, "solid": false},
	"lamp": {"n": "Lampu", "cost": 60, "w": 1, "h": 1, "solid": true},
	"bin": {"n": "Tempat Sampah", "cost": 30, "w": 1, "h": 1, "solid": true},
	"tree": {"n": "Pohon", "cost": 25, "w": 1, "h": 1, "solid": true},
	"kiosk": {"n": "Kios Makanan", "cost": 400, "w": 1, "h": 1, "solid": true},
	"gate": {"n": "Pintu Masuk", "cost": 0, "w": 1, "h": 1, "solid": false},
}
const BUILD_ORDER = ["path", "enc", "bench", "lamp", "bin", "tree", "kiosk"]

const RESEARCH = [
	{"id": "r_unc", "n": "Zoologi Dasar", "d": "Membuka hewan Tidak Umum (Rusa, Zebra, Burung Unta).", "cost": 400, "rep": 2, "req": ""},
	{"id": "r_rare", "n": "Zoologi Lanjutan", "d": "Membuka hewan Langka (Singa, Harimau, Beruang, Gajah).", "cost": 15000, "rep": 8, "req": "r_unc"},
	{"id": "r_epic", "n": "Paleontologi", "d": "Membuka dinosaurus Epik (Velociraptor, Stegosaurus, Triceratops).", "cost": 400000, "rep": 25, "req": "r_rare"},
	{"id": "r_leg", "n": "Rekayasa DNA Purba", "d": "Membuka dinosaurus Legendaris (T-Rex, Brachiosaurus, Spinosaurus).", "cost": 20000000, "rep": 45, "req": "r_epic"},
	{"id": "r_t3", "n": "Habitat Premium", "d": "Membuka upgrade kandang Tier 3.", "cost": 3000, "rep": 5, "req": ""},
	{"id": "r_t4", "n": "Habitat Maju", "d": "Membuka upgrade kandang Tier 4.", "cost": 120000, "rep": 20, "req": "r_t3"},
	{"id": "r_t5", "n": "Habitat Mewah", "d": "Membuka upgrade kandang Tier 5.", "cost": 6000000, "rep": 40, "req": "r_t4"},
	{"id": "r_slot2", "n": "Inkubator ke-2", "d": "Tambah 1 slot inkubator.", "cost": 300, "rep": 0, "req": ""},
	{"id": "r_slot3", "n": "Inkubator ke-3", "d": "Tambah 1 slot inkubator.", "cost": 5000, "rep": 6, "req": "r_slot2"},
	{"id": "r_slot4", "n": "Inkubator ke-4", "d": "Tambah 1 slot inkubator.", "cost": 150000, "rep": 22, "req": "r_slot3"},
	{"id": "r_vet", "n": "Klinik Hewan", "d": "Membuka perekrutan Dokter Hewan.", "cost": 800, "rep": 2, "req": ""},
	{"id": "r_sec", "n": "Sistem Keamanan", "d": "Membuka perekrutan Satpam.", "cost": 2500, "rep": 5, "req": ""},
	{"id": "r_mgmt", "n": "Manajemen Operasional", "d": "Membuka Mekanik dan Administrator.", "cost": 10000, "rep": 8, "req": ""},
	{"id": "r_ops", "n": "Efisiensi Biaya", "d": "Biaya pemeliharaan hewan -15%.", "cost": 50000, "rep": 15, "req": "r_mgmt"},
	{"id": "r_mkt", "n": "Pemasaran", "d": "Pengunjung datang 30% lebih sering.", "cost": 2000, "rep": 4, "req": ""},
	{"id": "r_mkt2", "n": "Iklan Global", "d": "Pengunjung datang 40% lebih sering.", "cost": 500000, "rep": 30, "req": "r_mkt"},
]

const STAFF_ORDER = ["keeper", "cleaner", "vet", "guard", "mechanic", "admin"]
const STAFF = {
	"keeper": {"n": "Penjaga Hewan", "hire": 200, "sal": 30, "res": "", "d": "Memberi makan hewan yang lapar secara otomatis."},
	"cleaner": {"n": "Petugas Kebersihan", "hire": 150, "sal": 20, "res": "", "d": "Menjaga kebersihan kebun binatang."},
	"vet": {"n": "Dokter Hewan", "hire": 400, "sal": 45, "res": "r_vet", "d": "Memulihkan kesehatan hewan."},
	"guard": {"n": "Satpam", "hire": 400, "sal": 40, "res": "r_sec", "d": "Mengurangi risiko hewan kabur."},
	"mechanic": {"n": "Mekanik", "hire": 500, "sal": 50, "res": "r_mgmt", "d": "Biaya perawatan fasilitas -5% (maks 5)."},
	"admin": {"n": "Administrator", "hire": 800, "sal": 80, "res": "r_mgmt", "d": "Pendapatan +10% per orang (maks 3)."},
}

const GOALS = [
	{"v": 1000.0, "n": "Rintisan: kumpulkan kekayaan $1K"},
	{"v": 10000.0, "n": "Berkembang: kekayaan $10K"},
	{"v": 100000.0, "n": "Kebun Binatang Kota: $100K"},
	{"v": 1000000.0, "n": "Jutawan: $1 Juta"},
	{"v": 10000000.0, "n": "Taipan Satwa: $10 Juta"},
	{"v": 100000000.0, "n": "Raja Dinosaurus: $100 Juta"},
	{"v": 1000000000.0, "n": "MILIARDER: $1 Miliar"},
]


static func money(v):
	var a = absf(v)
	var s = "-" if v < 0.0 else ""
	if a >= 1.0e12:
		return "%s$%.2fT" % [s, a / 1.0e12]
	if a >= 1.0e9:
		return "%s$%.2fM" % [s, a / 1.0e9]  # M = miliar
	if a >= 1.0e6:
		return "%s$%.2fJt" % [s, a / 1.0e6]
	if a >= 1.0e4:
		return "%s$%.1fK" % [s, a / 1.0e3]
	return "%s$%d" % [s, int(a)]


static func fmt_secs(sec):
	var s = int(ceil(maxf(sec, 0.0)))
	return "%d:%02d" % [s / 60, s % 60]
