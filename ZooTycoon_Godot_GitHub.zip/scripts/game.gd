extends Node2D
# ZOO TYCOON: FROM BROKE TO BILLIONAIRE - game core (state, simulation, rendering, input, save)

const Z = preload("res://scripts/data.gd")
const UIScript = preload("res://scripts/ui.gd")
const T = 32
const SAVE_PATH = "user://save.json"
const BAK_PATH = "user://save.bak"
const TMP_PATH = "user://save.tmp"
const SET_PATH = "user://settings.json"
const DIRS = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var ui
var cam
var state = "menu"
var is_touch = false

# ---- persistent game state
var cash = 500.0
var day = 1
var day_t = 0.0
var land = Z.START_LAND
var expansions = 0
var objs = []
var animals = []
var incub = []
var research = {}
var staff_n = {}
var ticket = 5.0
var rep = 0.0
var clean = 100.0
var stats = {}
var today = {}
var last_day = {}
var next_id = 1
var won = false
var settings = {"sfx": true, "vol": 0.7, "fps": 60, "touch": true, "low": false}

# ---- runtime state
var occ = {}
var path_set = {}
var enc_by_id = {}
var enc_views = {}
var encs = []
var decor = {}
var visitors = []
var staff_walk = []
var effects = []
var player = {"pos": Vector2(29 * T + 16, 31 * T), "face": 1}
var speed = 1.0
var paused = false
var tool = "select"
var rot = 0
var ghost = Vector2i(0, 0)
var moving = null
var selected_animal = null
var selected_obj = null
var total_attr = 0.0
var net_worth = 0.0
var can_visit = false
var spawn_t = 2.0
var tick_t = 0.0
var price_warn = false
var follow = true
var lmb = false
var drag_dist = 0.0
var panning = false
var touches = {}
var pinch_d = 0.0
var hint = ""
var sounds = {}
var players = []


func _ready():
	is_touch = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	settings["touch"] = is_touch
	cam = Camera2D.new()
	add_child(cam)
	cam.make_current()
	ui = UIScript.new()
	add_child(ui)
	load_settings()
	ui.setup(self)
	make_sounds()
	apply_settings()
	new_game()
	state = "menu"
	ui.show_menu()


# =====================================================================
# textures & sound
# =====================================================================
var tex_cache = {}


func tex(path):
	if tex_cache.has(path):
		return tex_cache[path]
	var t = null
	if ResourceLoader.exists(path):
		t = load(path)
	if t == null:
		var img = Image.create(32, 32, false, Image.FORMAT_RGBA8)
		img.fill(Color(1, 0, 1, 0.6))
		t = ImageTexture.create_from_image(img)
	tex_cache[path] = t
	return t


func sp_tex(id):
	var sp = Z.SPECIES[id]
	return tex("res://assets/%s/%s.png" % [sp.dir, id])


func make_tone(freq, dur, vol):
	var n = int(22050 * dur)
	var data = PackedByteArray()
	data.resize(n)
	for i in range(n):
		var env = 1.0 - float(i) / n
		var s = sin(TAU * freq * i / 22050.0) * vol * env
		data[i] = int(s * 127.0) & 255
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_8_BITS
	w.mix_rate = 22050
	w.data = data
	return w


func make_sounds():
	sounds["click"] = make_tone(660, 0.05, 0.5)
	sounds["coin"] = make_tone(990, 0.12, 0.5)
	sounds["error"] = make_tone(180, 0.18, 0.6)
	sounds["hatch"] = make_tone(520, 0.35, 0.6)
	for i in range(4):
		var p = AudioStreamPlayer.new()
		add_child(p)
		players.append(p)


func sfx(name):
	if not settings.sfx or not sounds.has(name):
		return
	for p in players:
		if not p.playing:
			p.stream = sounds[name]
			p.volume_db = linear_to_db(maxf(settings.vol, 0.001))
			p.play()
			return


func apply_settings():
	Engine.max_fps = int(settings.fps)


func save_settings():
	var f = FileAccess.open(SET_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))
		f.close()


func load_settings():
	if not FileAccess.file_exists(SET_PATH):
		return
	var f = FileAccess.open(SET_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if d is Dictionary:
		for k in d.keys():
			if settings.has(k):
				settings[k] = d[k]


# =====================================================================
# new game / state helpers
# =====================================================================
func fresh_today():
	return {"rev": 0.0, "exp": 0.0, "visitors": 0, "ticket": 0.0, "shop": 0.0, "upkeep": 0.0, "salary": 0.0, "food": 0.0, "build": 0.0}


func new_game():
	cash = 500.0
	day = 1
	day_t = 0.0
	land = Z.START_LAND
	expansions = 0
	objs = []
	animals = []
	incub = []
	research = {}
	staff_n = {}
	ticket = 5.0
	rep = 0.0
	clean = 100.0
	stats = {"total_rev": 0.0, "total_exp": 0.0, "total_visitors": 0, "sat_avg": 70.0}
	today = fresh_today()
	last_day = fresh_today()
	next_id = 1
	won = false
	visitors = []
	effects = []
	tool = "select"
	moving = null
	selected_animal = null
	selected_obj = null
	objs.append({"id": next_id, "type": "gate", "x": Z.GATE.x, "y": Z.GATE.y, "rot": 0, "tier": 1})
	next_id += 1
	for i in range(1, 5):
		objs.append({"id": next_id, "type": "path", "x": Z.GATE.x, "y": Z.GATE.y - i, "rot": 0, "tier": 1})
		next_id += 1
	player = {"pos": Vector2(Z.GATE.x * T + 16, (Z.GATE.y - 2) * T + 24), "face": 1}
	cam.position = player.pos
	cam.zoom = Vector2(1.0, 1.0)
	speed = 1.0
	paused = false
	rebuild()
	sync_staff()


func add_rev(kind, v):
	cash += v
	stats.total_rev += v
	today.rev += v
	today[kind] = today[kind] + v


func add_exp(kind, v):
	cash -= v
	stats.total_exp += v
	today.exp += v
	today[kind] = today[kind] + v


func admin_mult():
	return 1.0 + 0.1 * minf(3.0, staff_n.get("admin", 0))


func slot_count():
	var n = 1
	for id in ["r_slot2", "r_slot3", "r_slot4"]:
		if research.has(id):
			n += 1
	return n


func max_tier():
	var t = 2
	for i in range(3, 6):
		if research.has(Z.TIER_RES[i]):
			t = i
	return t


func willingness():
	return 4.0 + total_attr * 0.05


func visitor_cap():
	var c = 6.0 + encs.size() * 3.0 + rep * 0.3
	if settings.low:
		c *= 0.5
	return int(minf(60.0, c))


func mkt_mult():
	var m = 1.0
	if research.has("r_mkt"):
		m += 0.3
	if research.has("r_mkt2"):
		m += 0.4
	return m


func species_lock(id):
	var sp = Z.SPECIES[id]
	var rr = Z.RARITY_RES[sp.r]
	if rr != "" and not research.has(rr):
		for r in Z.RESEARCH:
			if r.id == rr:
				return "Riset: " + r.n
	if rep < sp.rep:
		return "Reputasi %d" % sp.rep
	return ""


func animal_growth(a):
	if a.age < 1.0:
		return 0.5
	if a.age < 3.0:
		return 0.8
	return 1.0


func animal_attr(a):
	var sp = Z.SPECIES[a.sp]
	var e = enc_by_id.get(a.enc)
	var tier = 1
	if e:
		tier = e.tier
	var v = sp.attr * animal_growth(a) * (0.3 + 0.7 * a.hap / 100.0) * (1.0 + 0.15 * (tier - 1))
	if a.sat < 15.0:
		v *= 0.5
	return v


func animal_upkeep(a):
	var sp = Z.SPECIES[a.sp]
	var u = maxf(1.0, sp.p * 0.004)
	if research.has("r_ops"):
		u *= 0.85
	return u


func food_cost(a):
	return maxf(1.0, Z.SPECIES[a.sp].p * 0.001)


func staff_mult():
	return 1.0 + sqrt(total_attr) * 0.02


func enc_count(e):
	var n = 0
	for a in animals:
		if a.enc == e.id:
			n += 1
	return n


func toast(text, bad = false):
	if ui:
		ui.toast(text, bad)


# =====================================================================
# map: occupancy, paths, enclosure info
# =====================================================================
func rebuild():
	occ = {}
	path_set = {}
	enc_by_id = {}
	enc_views = {}
	encs = []
	decor = {"bench": 0, "lamp": 0, "bin": 0, "tree": 0, "kiosk": 0}
	for o in objs:
		o.x = int(o.x)
		o.y = int(o.y)
		var d = Z.OBJ[o.type]
		for i in range(d.w):
			for j in range(d.h):
				occ[Vector2i(o.x + i, o.y + j)] = o
		if o.type == "path" or o.type == "gate":
			path_set[Vector2i(o.x, o.y)] = true
		elif o.type == "enc":
			enc_by_id[o.id] = o
			encs.append(o)
		elif decor.has(o.type):
			decor[o.type] += 1
	for e in encs:
		var views = []
		for k in range(6):
			views.append(Vector2i(e.x - 1, e.y + k))
			views.append(Vector2i(e.x + 6, e.y + k))
			views.append(Vector2i(e.x + k, e.y - 1))
			views.append(Vector2i(e.x + k, e.y + 6))
		var vv = []
		for v in views:
			if path_set.has(v):
				vv.append(v)
		enc_views[e.id] = vv
		var en = 0.0
		for o in objs:
			if o.type == "bench" or o.type == "lamp" or o.type == "tree":
				if o.x >= e.x - 3 and o.x <= e.x + 8 and o.y >= e.y - 3 and o.y <= e.y + 8:
					en += 4.0 if o.type == "tree" else 3.0
		e.enrich = minf(15.0, en)
	recompute()


func recompute():
	total_attr = 0.0
	for e in encs:
		e.attr = 0.0
		e.count = 0
		e.hap_sum = 0.0
		e.hap_avg = 50.0
	var worth = cash
	for a in animals:
		var v = animal_attr(a)
		total_attr += v
		worth += Z.SPECIES[a.sp].p * 0.5
		var e = enc_by_id.get(a.enc)
		if e:
			e.attr += v
			e.count += 1
			e.hap_sum += a.hap
	for e in encs:
		if e.count > 0:
			e.hap_avg = e.hap_sum / e.count
	for o in objs:
		worth += Z.OBJ[o.type].cost * 0.5
	net_worth = worth
	# can visitors reach at least one occupied enclosure?
	can_visit = false
	if path_set.has(Z.GATE):
		var prev = bfs(Z.GATE)
		for e in encs:
			if e.count > 0:
				for v in enc_views[e.id]:
					if prev.has(v):
						can_visit = true
						break
			if can_visit:
				break


func bfs(start):
	var prev = {start: start}
	var q = [start]
	var i = 0
	while i < q.size():
		var c = q[i]
		i += 1
		for d in DIRS:
			var n = c + d
			if path_set.has(n) and not prev.has(n):
				prev[n] = c
				q.append(n)
	return prev


func route_from(prev, start, goal):
	var r = []
	var c = goal
	var guard = 0
	while c != start and guard < 3000:
		r.push_front(c)
		c = prev[c]
		guard += 1
	return r


func tile_of(p):
	return Vector2i(int(floor(p.x / T)), int(floor(p.y / T)))


func enc_rect(e):
	return Rect2((e.x + 1) * T + 16, (e.y + 1) * T + 16, 4 * T - 32, 4 * T - 32)


# =====================================================================
# building
# =====================================================================
func obj_cost(type):
	return float(Z.OBJ[type].cost)


func can_place(type, x, y, ignore = null):
	var d = Z.OBJ[type]
	for i in range(d.w):
		for j in range(d.h):
			var t = Vector2i(x + i, y + j)
			if not land.has_point(t):
				return "Di luar tanah milikmu (beli tanah dulu)"
			if occ.has(t) and occ[t] != ignore:
				return "Tempat sudah terisi"
	if type != "path":
		var front = Vector2i(Z.GATE.x, Z.GATE.y - 1)
		for i in range(d.w):
			for j in range(d.h):
				if Vector2i(x + i, y + j) == front:
					return "Menghalangi pintu masuk"
	if ignore == null and cash < obj_cost(type):
		return "Uang tidak cukup (butuh %s)" % Z.money(obj_cost(type))
	return ""


func place_at(type, tile, silent = false):
	var err = can_place(type, tile.x, tile.y)
	if err != "":
		if not silent:
			toast(err, true)
			sfx("error")
		return false
	add_exp("build", obj_cost(type))
	objs.append({"id": next_id, "type": type, "x": tile.x, "y": tile.y, "rot": rot, "tier": 1})
	next_id += 1
	rebuild()
	sfx("coin")
	return true


func place_current():
	if moving != null:
		var o = moving.obj
		var err = can_place(o.type, ghost.x, ghost.y, o)
		if err != "":
			toast(err, true)
			sfx("error")
			return
		var dx = (ghost.x - moving.ox) * T
		var dy = (ghost.y - moving.oy) * T
		o.x = ghost.x
		o.y = ghost.y
		if o.type == "enc":
			for a in animals:
				if a.enc == o.id:
					a.px += dx
					a.py += dy
					a.tx += dx
					a.ty += dy
		moving = null
		tool = "select"
		rebuild()
		sfx("coin")
		ui.on_tool_changed()
		return
	if Z.OBJ.has(tool) and tool != "select":
		place_at(tool, ghost)


func cancel_tool():
	if moving != null:
		var o = moving.obj
		o.x = moving.ox
		o.y = moving.oy
		moving = null
		rebuild()
	tool = "select"
	ui.on_tool_changed()


func set_tool(t):
	tool = t
	moving = null
	selected_animal = null
	selected_obj = null
	ui.on_tool_changed()


func start_move(o):
	if o.type == "gate":
		return
	moving = {"obj": o, "ox": o.x, "oy": o.y}
	# lift the object off the map while moving
	for k in occ.keys():
		if occ[k] == o:
			occ.erase(k)
	ghost = Vector2i(o.x, o.y)
	tool = o.type
	selected_obj = null
	ui.close_panel()
	ui.on_tool_changed()


func remove_obj(o):
	if o.type == "gate":
		toast("Pintu masuk tidak bisa dihapus", true)
		return
	if o.type == "enc" and enc_count(o) > 0:
		toast("Pindahkan atau jual hewan di kandang ini dulu", true)
		sfx("error")
		return
	cash += obj_cost(o.type) * 0.5
	objs.erase(o)
	selected_obj = null
	rebuild()
	sfx("coin")
	ui.close_panel()


func expand_cost():
	return 800.0 * pow(2.8, expansions)


func buy_land():
	if land.position.x <= 3 or land.position.y <= 3 or land.end.x >= Z.WORLD_W - 3:
		toast("Tanah sudah mencapai batas maksimum", true)
		return
	var cost = expand_cost()
	if cash < cost:
		toast("Uang tidak cukup (butuh %s)" % Z.money(cost), true)
		sfx("error")
		return
	add_exp("build", cost)
	land = Rect2i(land.position.x - 2, land.position.y - 2, land.size.x + 4, land.size.y + 2)
	expansions += 1
	sfx("coin")
	toast("Tanah diperluas!")
	rebuild()
	ui.on_change()


func upgrade_cost(e):
	var val = 0.0
	for a in animals:
		if a.enc == e.id:
			val += Z.SPECIES[a.sp].p
	return Z.TIER_COST[e.tier + 1] + val * 0.1


func upgrade_block(e):
	if e.tier >= 5:
		return "Tier maksimal"
	var t = e.tier + 1
	var rr = Z.TIER_RES[t]
	if rr != "" and not research.has(rr):
		for r in Z.RESEARCH:
			if r.id == rr:
				return "Butuh riset: " + r.n
	if cash < upgrade_cost(e):
		return "Uang kurang"
	return ""


func upgrade_enc(e):
	var b = upgrade_block(e)
	if b != "":
		toast(b, true)
		sfx("error")
		return
	add_exp("build", upgrade_cost(e))
	e.tier += 1
	rebuild()
	sfx("coin")
	toast("Kandang ditingkatkan ke Tier %d" % e.tier)
	ui.on_change()


# =====================================================================
# eggs, hatching, animals
# =====================================================================
func buy_egg(id):
	var sp = Z.SPECIES[id]
	if species_lock(id) != "":
		toast("Belum terbuka", true)
		return
	if incub.size() >= slot_count():
		toast("Semua slot inkubator penuh", true)
		sfx("error")
		return
	if cash < sp.p:
		toast("Uang tidak cukup (butuh %s)" % Z.money(sp.p), true)
		sfx("error")
		return
	add_exp("build", sp.p)
	incub.append({"sp": id, "t": float(sp.inc), "total": float(sp.inc)})
	sfx("coin")
	toast("%s dimasukkan ke inkubator" % Z.KIND_NAMES[sp.kind])
	recompute()
	ui.on_change()


func find_enc_for(id):
	var sp = Z.SPECIES[id]
	var best = null
	for e in encs:
		if e.tier < sp.tier:
			continue
		var n = enc_count(e)
		if n >= Z.TIER_CAP[e.tier]:
			continue
		if n == 0:
			if best == null:
				best = e
		else:
			var first = null
			for a in animals:
				if a.enc == e.id:
					first = a
					break
			if first != null and first.sp == id:
				return e
	return best


func hatch(it):
	if it.t > 0.0:
		return
	var e = find_enc_for(it.sp)
	if e == null:
		var sp = Z.SPECIES[it.sp]
		toast("Tidak ada kandang cocok (butuh Tier %d dengan ruang kosong)" % sp.tier, true)
		sfx("error")
		return
	var sp2 = Z.SPECIES[it.sp]
	var r = enc_rect(e)
	var a = {"id": next_id, "sp": it.sp, "name": "%s #%d" % [sp2.n, next_id], "sat": 80.0, "hap": 60.0, "health": 100.0,
		"age": 0.0, "enc": e.id, "px": r.position.x + randf() * r.size.x, "py": r.position.y + randf() * r.size.y,
		"tx": 0.0, "ty": 0.0, "wt": 0.0, "face": 1}
	a.tx = a.px
	a.ty = a.py
	next_id += 1
	animals.append(a)
	incub.erase(it)
	effects.append({"pos": Vector2(a.px, a.py), "t": 1.0, "k": "hatch"})
	sfx("hatch")
	toast("%s menetas!" % sp2.n)
	recompute()
	ui.on_change()


func feed(a, silent = false):
	var c = food_cost(a)
	if cash < c:
		if not silent:
			toast("Uang tidak cukup untuk pakan", true)
			sfx("error")
		return false
	add_exp("food", c)
	a.sat = 100.0
	if not silent:
		sfx("click")
	return true


func feed_all():
	var n = 0
	for a in animals:
		if a.sat < 80.0 and feed(a, true):
			n += 1
	toast("Memberi makan %d hewan" % n)
	ui.on_change()


func sell_animal(a):
	cash += Z.SPECIES[a.sp].p * 0.5
	animals.erase(a)
	if selected_animal == a:
		selected_animal = null
	sfx("coin")
	recompute()
	ui.on_change()


func move_animal(a):
	var sp = Z.SPECIES[a.sp]
	var start = 0
	for i in range(encs.size()):
		if encs[i].id == a.enc:
			start = i
	for k in range(1, encs.size() + 1):
		var e = encs[(start + k) % encs.size()]
		if e.id == a.enc or e.tier < sp.tier:
			continue
		var n = enc_count(e)
		var ok = n < Z.TIER_CAP[e.tier]
		if n > 0:
			for b in animals:
				if b.enc == e.id:
					if b.sp != a.sp:
						ok = false
					break
		if ok:
			a.enc = e.id
			var r = enc_rect(e)
			a.px = r.position.x + randf() * r.size.x
			a.py = r.position.y + randf() * r.size.y
			a.tx = a.px
			a.ty = a.py
			recompute()
			toast("Hewan dipindahkan")
			ui.on_change()
			return
	toast("Tidak ada kandang lain yang cocok", true)


func do_research(r):
	if research.has(r.id):
		return
	if rep < r.rep:
		toast("Reputasi belum cukup", true)
		return
	if r.req != "" and not research.has(r.req):
		toast("Selesaikan riset sebelumnya dulu", true)
		return
	if cash < r.cost:
		toast("Uang tidak cukup", true)
		sfx("error")
		return
	add_exp("build", r.cost)
	research[r.id] = true
	sfx("coin")
	toast("Riset selesai: " + r.n)
	ui.on_change()


func staff_locked(role):
	var rr = Z.STAFF[role].res
	return rr != "" and not research.has(rr)


func hire(role):
	var d = Z.STAFF[role]
	if staff_locked(role):
		toast("Butuh riset dulu", true)
		return
	if cash < d.hire:
		toast("Uang tidak cukup", true)
		sfx("error")
		return
	add_exp("build", d.hire)
	staff_n[role] = staff_n.get(role, 0) + 1
	sync_staff()
	sfx("coin")
	ui.on_change()


func fire(role):
	if staff_n.get(role, 0) > 0:
		staff_n[role] -= 1
		sync_staff()
		ui.on_change()


func sync_staff():
	staff_walk = []
	for role in Z.STAFF_ORDER:
		for i in range(staff_n.get(role, 0)):
			var p = Vector2(Z.GATE.x * T + 16, (Z.GATE.y - 1) * T + 16)
			staff_walk.append({"role": role, "pos": p, "face": 1, "tgt": p})


# =====================================================================
# simulation
# =====================================================================
func _process(delta):
	if state != "play":
		queue_redraw()
		return
	update_player(delta)
	var dt = delta * speed
	if not paused:
		sim(dt)
	queue_redraw()


func sim(dt):
	day_t += dt
	if day_t >= Z.DAY_LEN:
		day_t -= Z.DAY_LEN
		end_day()
	for it in incub:
		it.t = maxf(0.0, it.t - dt)
	update_animals(dt)
	update_visitors(dt)
	update_staff(dt)
	try_spawn(dt)
	for fx in effects:
		fx.t -= delta_fx(dt)
	effects = effects.filter(func(f): return f.t > 0.0)
	clean = clampf(clean - visitors.size() * 0.004 * dt * pow(0.96, minf(decor.bin, 10)) + staff_n.get("cleaner", 0) * 0.3 * dt, 0.0, 100.0)
	var vets = staff_n.get("vet", 0)
	if vets > 0:
		for a in animals:
			a.health = minf(100.0, a.health + 0.4 * vets * dt)
	tick_t += dt
	if tick_t >= 1.0:
		tick_t = 0.0
		tick()


func delta_fx(dt):
	return dt * 0.8


func tick():
	recompute()
	# keepers feed hungry animals automatically
	var keepers = staff_n.get("keeper", 0)
	if keepers > 0:
		var left = keepers
		for a in animals:
			if left <= 0:
				break
			if a.sat < 45.0 and feed(a, true):
				left -= 1
	update_hint()
	if not won and net_worth >= 1.0e9:
		won = true
		ui.show_win()


func update_hint():
	if encs.size() == 0:
		hint = "Buka Bangun > Kandang, taruh di tanah, lalu buat Jalan dari pintu masuk ke dekat kandang."
	elif animals.size() == 0 and incub.size() == 0:
		hint = "Buka Toko dan beli telur/kapsul pertamamu."
	elif animals.size() == 0:
		hint = "Tunggu inkubasi selesai, lalu tekan Tetas di Toko."
	elif not can_visit:
		hint = "Hubungkan jalan dari pintu masuk sampai menempel di pagar kandang agar pengunjung bisa datang."
	elif price_warn:
		hint = "Tiket terlalu mahal untuk pengunjung! Turunkan harga atau tekan Auto."
	else:
		hint = "Tujuan: " + next_goal_text()


func next_goal_text():
	for g in Z.GOALS:
		if net_worth < g.v:
			return "%s (sekarang %s)" % [g.n, Z.money(net_worth)]
	return "Kamu sudah miliarder! Terus kembangkan kebun binatangmu."


func end_day():
	var mech = minf(5.0, staff_n.get("mechanic", 0))
	var up = 0.0
	for a in animals:
		up += animal_upkeep(a)
	var sal = 0.0
	for role in Z.STAFF_ORDER:
		sal += staff_n.get(role, 0) * Z.STAFF[role].sal
	sal *= staff_mult()
	var maint = 0.0
	for o in objs:
		maint += obj_cost(o.type) * 0.002
	maint *= (1.0 - 0.05 * mech)
	add_exp("upkeep", up + maint)
	add_exp("salary", sal)
	# animal escapes
	var guards = staff_n.get("guard", 0)
	for e in encs:
		for a in animals:
			if a.enc != e.id:
				continue
			var sp = Z.SPECIES[a.sp]
			if sp.r >= 2 or sp.tier >= 2:
				var risk = maxf(0.0, 0.2 - 0.04 * e.tier) * (1.0 + sp.r * 0.5) * maxf(0.0, 1.0 - 0.3 * guards)
				if randf() < risk:
					var fine = sp.p * 0.03
					add_exp("upkeep", fine)
					rep = maxf(0.0, rep - 2.0)
					toast("%s kabur sebentar! Denda %s" % [sp.n, Z.money(fine)], true)
					break
	# animals grow older / dead animals
	var dead = []
	for a in animals:
		if a.health <= 0.0:
			dead.append(a)
	for a in dead:
		animals.erase(a)
		rep = maxf(0.0, rep - 3.0)
		toast("%s mati karena kelaparan/sakit" % a.name, true)
	last_day = today.duplicate()
	toast("Hari %d selesai: %s pendapatan, %s biaya" % [day, Z.money(last_day.rev), Z.money(last_day.exp)])
	today = fresh_today()
	day += 1
	if cash < 0.0:
		toast("Kas negatif! Naikkan pendapatan atau kurangi biaya.", true)
	recompute()
	save_game(true)
	ui.on_change()


func update_animals(dt):
	for a in animals:
		a.age += dt / Z.DAY_LEN
		a.sat = maxf(0.0, a.sat - 0.9 * dt)
		if a.sat < 15.0:
			a.health = maxf(0.0, a.health - 0.6 * dt)
		else:
			a.health = minf(100.0, a.health + 0.2 * dt)
		var e = enc_by_id.get(a.enc)
		var tier = 1
		var enr = 0.0
		if e:
			tier = e.tier
			enr = e.enrich
		var target = 35.0 + tier * 8.0 + enr + (a.sat - 50.0) * 0.3 + (a.health - 50.0) * 0.1
		a.hap += (clampf(target, 0.0, 100.0) - a.hap) * minf(1.0, dt * 0.2)
		if e == null:
			continue
		a.wt -= dt
		var r = enc_rect(e)
		if a.wt <= 0.0:
			a.wt = randf_range(2.0, 5.0)
			a.tx = r.position.x + randf() * r.size.x
			a.ty = r.position.y + randf() * r.size.y
		var d = Vector2(a.tx - a.px, a.ty - a.py)
		var l = d.length()
		if l > 1.0:
			var step = minf(l, 18.0 * dt)
			a.px += d.x / l * step
			a.py += d.y / l * step
			if absf(d.x) > 0.5:
				a.face = 1 if d.x > 0 else -1
		a.px = clampf(a.px, r.position.x, r.end.x)
		a.py = clampf(a.py, r.position.y, r.end.y)


func move_towards(o, target, spd, dt):
	var d = target - o.pos
	var l = d.length()
	if l <= spd * dt:
		o.pos = target
		return true
	o.pos += d / l * spd * dt
	if absf(d.x) > 0.5:
		o.face = 1 if d.x > 0 else -1
	return false


func follow_route(v, dt):
	if v.route.is_empty():
		return true
	var tgt = Vector2(v.route[0].x * T + T / 2.0, v.route[0].y * T + T / 2.0)
	if move_towards(v, tgt, 60.0, dt):
		v.route.pop_front()
	return v.route.is_empty()


func try_spawn(dt):
	spawn_t -= dt
	if spawn_t > 0.0:
		return
	var rate = (0.5 + sqrt(total_attr) * 0.05 + rep * 0.05) * mkt_mult()
	spawn_t = 6.0 / (1.0 + rate)
	if not can_visit or visitors.size() >= visitor_cap():
		return
	if ticket > willingness() * 1.15:
		price_warn = true
		return
	price_warn = false
	visitors.append({"pos": Vector2(Z.GATE.x * T + T / 2.0, (Z.GATE.y + 6) * T + T / 2.0), "face": 1, "route": [], "st": "in",
		"t": 0.0, "sat": 75.0, "kind": randi() % 4, "seen": 0, "max_seen": randi_range(2, 5), "enc": 0, "visited": []})


func update_visitors(dt):
	var i = visitors.size() - 1
	while i >= 0:
		var v = visitors[i]
		var gone = false
		match v.st:
			"in":
				if move_towards(v, Vector2(v.pos.x, Z.GATE.y * T + T / 2.0), 60.0, dt):
					var price = ticket * admin_mult()
					add_rev("ticket", price)
					today.visitors += 1
					stats.total_visitors += 1
					v.st = "think"
			"think":
				think(v)
			"walk":
				if follow_route(v, dt):
					v.st = "watch"
					v.t = randf_range(3.0, 6.0)
			"watch":
				v.t -= dt
				if v.t <= 0.0:
					var e = enc_by_id.get(v.enc)
					if e:
						v.sat = minf(100.0, v.sat + clampf((e.hap_avg - 50.0) * 0.08, -4.0, 4.0) + 2.0)
					v.st = "think"
			"leave":
				if follow_route(v, dt):
					v.st = "out"
			"out":
				if move_towards(v, Vector2(Z.GATE.x * T + T / 2.0, (Z.GATE.y + 6) * T + T / 2.0), 60.0, dt):
					gone = true
		if gone:
			finish_visit(v)
			visitors.remove_at(i)
		i -= 1


func think(v):
	var tile = tile_of(v.pos)
	if not path_set.has(tile):
		v.st = "out"
		return
	var prev = bfs(tile)
	var cands = []
	var total = 0.0
	if v.seen < v.max_seen:
		for e in encs:
			if e.count > 0 and not v.visited.has(e.id):
				var reach = []
				for vt in enc_views[e.id]:
					if prev.has(vt):
						reach.append(vt)
				if not reach.is_empty():
					var w = e.attr + 1.0
					cands.append({"e": e, "vt": reach[randi() % reach.size()], "w": w})
					total += w
	if cands.is_empty():
		if prev.has(Z.GATE):
			v.route = route_from(prev, tile, Z.GATE)
			v.st = "leave"
		else:
			v.st = "out"
		return
	var r = randf() * total
	var pick = cands[0]
	for c in cands:
		r -= c.w
		if r <= 0.0:
			pick = c
			break
	v.route = route_from(prev, tile, pick.vt)
	v.enc = pick.e.id
	v.visited.append(pick.e.id)
	v.seen += 1
	v.st = "walk"


func finish_visit(v):
	var w = willingness()
	var n = decor.kiosk
	if n > 0 and randf() < 0.5 + 0.1 * minf(n, 4):
		add_rev("shop", w * 0.3 * randf_range(0.5, 1.0) * admin_mult())
	var sat = v.sat
	var ratio = ticket / w
	if ratio > 0.7:
		sat -= (ratio - 0.7) * 30.0
	if clean < 60.0:
		sat -= (60.0 - clean) * 0.25
	sat += minf(5.0, decor.bench) + minf(3.0, decor.lamp) + minf(3.0, decor.kiosk)
	sat = clampf(sat, 0.0, 100.0)
	stats.sat_avg = stats.sat_avg * 0.95 + sat * 0.05
	var delta = (sat - 65.0) * 0.01
	if delta > 0.0:
		delta *= (1.0 - rep / 100.0)
	else:
		delta *= (0.3 + rep / 100.0)
	rep = clampf(rep + delta, 0.0, 100.0)


func update_staff(dt):
	for s in staff_walk:
		if move_towards(s, s.tgt, 40.0, dt):
			var here = tile_of(s.pos)
			var opts = []
			for d in DIRS:
				if path_set.has(here + d):
					opts.append(here + d)
			if not opts.is_empty():
				var n = opts[randi() % opts.size()]
				s.tgt = Vector2(n.x * T + T / 2.0, n.y * T + T / 2.0)


# =====================================================================
# player movement & camera
# =====================================================================
func solid_at(p):
	var t = tile_of(p)
	if t.x < 0 or t.y < 0 or t.x >= Z.WORLD_W or t.y >= Z.WORLD_H:
		return true
	if occ.has(t):
		return Z.OBJ[occ[t].type].solid
	return false


func try_move(delta):
	var np = player.pos + delta
	for off in [Vector2(-7, 0), Vector2(7, 0), Vector2(-7, -8), Vector2(7, -8)]:
		if solid_at(np + off):
			return
	player.pos = np


func update_player(dt):
	var dir = Vector2.ZERO
	if not ui.panel_open():
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
			dir.y -= 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
			dir.y += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
			dir.x -= 1.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
			dir.x += 1.0
	dir += ui.joy_vec()
	if dir.length() > 1.0:
		dir = dir.normalized()
	if dir.length() > 0.05:
		follow = true
		var st = dir * 150.0 * dt
		try_move(Vector2(st.x, 0))
		try_move(Vector2(0, st.y))
		if absf(dir.x) > 0.1:
			player.face = 1 if dir.x > 0 else -1
	if follow:
		cam.position = cam.position.lerp(player.pos, minf(1.0, dt * 8.0))
	cam.position.x = clampf(cam.position.x, 0.0, Z.WORLD_W * T)
	cam.position.y = clampf(cam.position.y, 0.0, Z.WORLD_H * T)


func set_zoom(z):
	z = clampf(z, 0.5, 2.5)
	cam.zoom = Vector2(z, z)


func focus_on(p):
	follow = false
	cam.position = p


# =====================================================================
# input
# =====================================================================
func screen_to_world(p):
	return get_canvas_transform().affine_inverse() * p


func _unhandled_input(event):
	if state != "play":
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_ESCAPE:
				if ui.panel_open():
					ui.close_panel()
				elif tool != "select":
					cancel_tool()
				else:
					ui.open("menu")
			KEY_SPACE:
				paused = not paused
			KEY_R:
				rot = 1 - rot
			KEY_B:
				ui.open("build")
			KEY_ENTER:
				if tool != "select":
					place_current()
		return
	if event is InputEventMagnifyGesture:
		set_zoom(cam.zoom.x * event.factor)
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			touches[event.index] = event.position
		else:
			touches.erase(event.index)
			pinch_d = 0.0
		return
	if event is InputEventScreenDrag:
		touches[event.index] = event.position
		if touches.size() == 2:
			var ks = touches.keys()
			var d = touches[ks[0]].distance_to(touches[ks[1]])
			if pinch_d > 0.0 and d > 0.0:
				set_zoom(cam.zoom.x * d / pinch_d)
			pinch_d = d
		return
	if event is InputEventMouseButton:
		var wp = screen_to_world(event.position)
		var tile = tile_of(wp)
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			set_zoom(cam.zoom.x * 1.1)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			set_zoom(cam.zoom.x / 1.1)
		elif event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				lmb = true
				drag_dist = 0.0
				if tool == "path":
					ghost = tile
					place_at("path", tile, true)
			else:
				if lmb and drag_dist <= 10.0:
					on_click(wp, tile)
				lmb = false
		elif event.button_index == MOUSE_BUTTON_RIGHT or event.button_index == MOUSE_BUTTON_MIDDLE:
			panning = event.pressed
	elif event is InputEventMouseMotion:
		var wp2 = screen_to_world(event.position)
		var t2 = tile_of(wp2)
		if not is_touch:
			ghost = t2
		if panning:
			follow = false
			cam.position -= event.relative / cam.zoom.x
		elif lmb:
			drag_dist += event.relative.length()
			if tool == "path":
				ghost = t2
				place_at("path", t2, true)
			elif drag_dist > 10.0 and touches.size() < 2:
				follow = false
				cam.position -= event.relative / cam.zoom.x


func on_click(wp, tile):
	if tool == "select":
		var best = null
		var bd = 22.0
		for a in animals:
			var d = Vector2(a.px, a.py - 10).distance_to(wp)
			if d < bd:
				bd = d
				best = a
		if best != null:
			selected_animal = best
			selected_obj = null
			ui.open("animal_detail")
			return
		if occ.has(tile):
			selected_obj = occ[tile]
			selected_animal = null
			ui.open("obj")
			return
		selected_animal = null
		selected_obj = null
		return
	if tool == "path":
		return
	ghost = tile
	if not is_touch:
		place_current()


# =====================================================================
# drawing
# =====================================================================
func _draw():
	var vs = get_viewport_rect().size
	var half = vs / (2.0 * cam.zoom.x)
	var c0 = cam.position - half
	var c1 = cam.position + half
	var tx0 = maxi(0, int(floor(c0.x / T)))
	var ty0 = maxi(0, int(floor(c0.y / T)))
	var tx1 = mini(Z.WORLD_W - 1, int(floor(c1.x / T)))
	var ty1 = mini(Z.WORLD_H - 1, int(floor(c1.y / T)))
	var ga = tex("res://assets/terrain/grass_a.png")
	var gb = tex("res://assets/terrain/grass_b.png")
	var pt = tex("res://assets/terrain/path.png")
	var dt_ = tex("res://assets/terrain/dirt.png")
	for x in range(tx0, tx1 + 1):
		for y in range(ty0, ty1 + 1):
			var p = Vector2(x * T, y * T)
			var t = ga if (x * 7 + y * 13) % 5 > 1 else gb
			draw_texture(t, p)
			if path_set.has(Vector2i(x, y)):
				draw_texture(pt, p)
			if not land.has_point(Vector2i(x, y)):
				draw_rect(Rect2(p, Vector2(T, T)), Color(0, 0, 0, 0.32), true)
	draw_rect(Rect2(land.position.x * T, land.position.y * T, land.size.x * T, land.size.y * T), Color(1, 0.9, 0.3, 0.8), false, 2.0)
	# enclosure floors
	for e in encs:
		var col = Z.TIER_GROUND[e.tier]
		for i in range(1, 5):
			for j in range(1, 5):
				draw_texture(dt_, Vector2((e.x + i) * T, (e.y + j) * T), col)
	# collect y-sorted drawables
	var items = []
	for e in encs:
		items.append([(e.y + 6) * T, "enc", e])
	for o in objs:
		if o.type != "enc" and o.type != "path":
			items.append([(o.y + 1) * T - 1, "obj", o])
	for a in animals:
		items.append([a.py, "animal", a])
	for v in visitors:
		items.append([v.pos.y + 14, "visitor", v])
	for s in staff_walk:
		items.append([s.pos.y + 14, "staff", s])
	items.append([player.pos.y, "player", player])
	items.sort_custom(func(a, b): return a[0] < b[0])
	for it in items:
		match it[1]:
			"enc":
				draw_enc(it[2])
			"obj":
				draw_obj(it[2])
			"animal":
				draw_animal(it[2])
			"visitor":
				draw_person(tex("res://assets/visitors/visitor_%d.png" % it[2].kind), it[2].pos, it[2].face)
			"staff":
				draw_person(tex("res://assets/visitors/staff_%s.png" % it[2].role), it[2].pos, it[2].face)
			"player":
				draw_person(tex("res://assets/visitors/player.png"), it[2].pos, it[2].face)
	# effects
	for fx in effects:
		var k = 1.0 - fx.t
		draw_arc(fx.pos, 10.0 + k * 40.0, 0, TAU, 24, Color(1, 0.95, 0.4, fx.t), 3.0)
		draw_texture(tex("res://assets/props/egg.png"), fx.pos + Vector2(-16, -30 - k * 30.0), Color(1, 1, 1, fx.t))
	# selection / ghost
	if selected_obj != null and tool == "select":
		var d = Z.OBJ[selected_obj.type]
		draw_rect(Rect2(selected_obj.x * T, selected_obj.y * T, d.w * T, d.h * T), Color(1, 1, 0.3, 0.9), false, 3.0)
	if selected_animal != null and animals.has(selected_animal):
		draw_arc(Vector2(selected_animal.px, selected_animal.py), 20.0, 0, TAU, 20, Color(1, 1, 0.3, 0.95), 2.0)
	if tool != "select":
		draw_ghost()


func draw_person(t, pos, face):
	draw_set_transform(pos, 0.0, Vector2(face, 1))
	draw_texture(t, Vector2(-16, -28))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func draw_animal(a):
	var g = animal_growth(a)
	var s = 0.6 if g < 0.6 else (0.8 if g < 0.9 else 1.0)
	draw_set_transform(Vector2(a.px, a.py), 0.0, Vector2(a.face * s, s))
	draw_texture(sp_tex(a.sp), Vector2(-16, -26))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if a.sat < 25.0:
		draw_string(ThemeDB.fallback_font, Vector2(a.px - 4, a.py - 30), "!", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 0.3, 0.2))
	elif a.hap < 30.0:
		draw_string(ThemeDB.fallback_font, Vector2(a.px - 4, a.py - 30), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 0.8, 0.2))


func draw_enc(e):
	var fh = tex("res://assets/fences/fence_h.png")
	var fv = tex("res://assets/fences/fence_v.png")
	var fc = tex("res://assets/fences/fence_c.png")
	var col = Z.TIER_FENCE[e.tier]
	for i in range(6):
		for j in range(6):
			if i != 0 and i != 5 and j != 0 and j != 5:
				continue
			var p = Vector2((e.x + i) * T, (e.y + j) * T)
			var corner = (i == 0 or i == 5) and (j == 0 or j == 5)
			if corner:
				draw_texture(fc, p, col)
			elif j == 0 or j == 5:
				draw_texture(fh, p, col)
			else:
				draw_texture(fv, p, col)
	var sp_name = "Kosong"
	for a in animals:
		if a.enc == e.id:
			sp_name = Z.SPECIES[a.sp].n
			break
	var label = "%s %d/%d T%d" % [sp_name, enc_count(e), Z.TIER_CAP[e.tier], e.tier]
	draw_string(ThemeDB.fallback_font, Vector2(e.x * T - 20, e.y * T - 6), label, HORIZONTAL_ALIGNMENT_CENTER, 6 * T + 40, 13, Color(1, 1, 1))


func draw_obj(o):
	var p = Vector2(o.x * T, o.y * T)
	match o.type:
		"gate":
			draw_texture(tex("res://assets/terrain/path.png"), p)
			draw_texture(tex("res://assets/buildings/gate.png"), p)
			draw_string(ThemeDB.fallback_font, p + Vector2(-30, -6), "MASUK", HORIZONTAL_ALIGNMENT_CENTER, 92, 12, Color(1, 1, 0.6))
		"bench":
			draw_texture(tex("res://assets/props/bench_%s.png" % ("v" if o.rot == 1 else "h")), p)
		"lamp":
			draw_texture(tex("res://assets/props/lamp.png"), p)
		"bin":
			draw_texture(tex("res://assets/props/bin.png"), p)
		"tree":
			draw_texture(tex("res://assets/props/tree.png"), p + Vector2(0, -16))
		"kiosk":
			draw_texture(tex("res://assets/buildings/kiosk.png"), p)


func draw_ghost():
	var type = tool
	if not Z.OBJ.has(type):
		return
	var d = Z.OBJ[type]
	var ignore = null
	if moving != null:
		ignore = moving.obj
	var err = can_place(type, ghost.x, ghost.y, ignore)
	var ok = err == ""
	var col = Color(0.3, 1, 0.3, 0.45) if ok else Color(1, 0.3, 0.3, 0.45)
	var r = Rect2(ghost.x * T, ghost.y * T, d.w * T, d.h * T)
	draw_rect(r, col, true)
	draw_rect(r, Color(1, 1, 1, 0.8), false, 2.0)
	var label = "%s  %s" % [d.n, Z.money(obj_cost(type)) if moving == null else "pindah"]
	draw_string(ThemeDB.fallback_font, r.position + Vector2(0, -6), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 1, 1))
	if not ok:
		draw_string(ThemeDB.fallback_font, r.position + Vector2(0, r.size.y + 16), err, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 0.6, 0.5))


# =====================================================================
# save / load
# =====================================================================
func save_game(auto = false):
	var d = {
		"v": Z.VERSION, "cash": cash, "day": day, "day_t": day_t,
		"land": [land.position.x, land.position.y, land.size.x, land.size.y], "exp": expansions,
		"objs": objs, "animals": animals, "incub": incub, "research": research, "staff": staff_n,
		"ticket": ticket, "rep": rep, "clean": clean, "stats": stats, "today": today, "last_day": last_day,
		"next_id": next_id, "won": won, "settings": settings,
	}
	var text = JSON.stringify(d)
	var f = FileAccess.open(TMP_PATH, FileAccess.WRITE)
	if f == null:
		toast("Gagal menyimpan", true)
		return false
	f.store_string(text)
	f.close()
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.copy_absolute(ProjectSettings.globalize_path(SAVE_PATH), ProjectSettings.globalize_path(BAK_PATH))
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	var err = DirAccess.rename_absolute(ProjectSettings.globalize_path(TMP_PATH), ProjectSettings.globalize_path(SAVE_PATH))
	if err != OK:
		var f2 = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
		if f2:
			f2.store_string(text)
			f2.close()
	save_settings()
	if not auto:
		toast("Game disimpan")
	return true


func has_save():
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(BAK_PATH)


func read_save(path):
	if not FileAccess.file_exists(path):
		return null
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null:
		return null
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if d is Dictionary and d.has("v") and d.has("objs"):
		return d
	return null


func load_game():
	var d = read_save(SAVE_PATH)
	if d == null:
		d = read_save(BAK_PATH)
	if d == null:
		toast("Data simpanan tidak ditemukan atau rusak", true)
		return false
	if int(d.v) > Z.VERSION:
		toast("Data simpanan dari versi game yang lebih baru", true)
		return false
	new_game()
	cash = float(d.get("cash", 500.0))
	day = int(d.get("day", 1))
	day_t = float(d.get("day_t", 0.0))
	var l = d.get("land", [22, 23, 16, 12])
	land = Rect2i(int(l[0]), int(l[1]), int(l[2]), int(l[3]))
	expansions = int(d.get("exp", 0))
	objs = []
	for o in d.get("objs", []):
		if Z.OBJ.has(str(o.get("type", ""))):
			objs.append({"id": int(o.get("id", 0)), "type": str(o.type), "x": int(o.get("x", 0)), "y": int(o.get("y", 0)),
				"rot": int(o.get("rot", 0)), "tier": clampi(int(o.get("tier", 1)), 1, 5)})
	var has_gate = false
	for o in objs:
		if o.type == "gate":
			has_gate = true
	if not has_gate:
		objs.append({"id": 999999, "type": "gate", "x": Z.GATE.x, "y": Z.GATE.y, "rot": 0, "tier": 1})
	animals = []
	for a in d.get("animals", []):
		if Z.SPECIES.has(str(a.get("sp", ""))):
			animals.append({"id": int(a.get("id", 0)), "sp": str(a.sp), "name": str(a.get("name", "Hewan")),
				"sat": float(a.get("sat", 80)), "hap": float(a.get("hap", 60)), "health": float(a.get("health", 100)),
				"age": float(a.get("age", 0)), "enc": int(a.get("enc", 0)), "px": float(a.get("px", 0)), "py": float(a.get("py", 0)),
				"tx": float(a.get("px", 0)), "ty": float(a.get("py", 0)), "wt": 0.0, "face": 1})
	incub = []
	for it in d.get("incub", []):
		if Z.SPECIES.has(str(it.get("sp", ""))):
			incub.append({"sp": str(it.sp), "t": float(it.get("t", 0)), "total": maxf(1.0, float(it.get("total", 1)))})
	research = {}
	for k in d.get("research", {}).keys():
		research[str(k)] = true
	staff_n = {}
	for k in d.get("staff", {}).keys():
		if Z.STAFF.has(str(k)):
			staff_n[str(k)] = int(d.staff[k])
	ticket = float(d.get("ticket", 5.0))
	rep = float(d.get("rep", 0.0))
	clean = float(d.get("clean", 100.0))
	var s = d.get("stats", {})
	stats = {"total_rev": float(s.get("total_rev", 0)), "total_exp": float(s.get("total_exp", 0)),
		"total_visitors": int(s.get("total_visitors", 0)), "sat_avg": float(s.get("sat_avg", 70))}
	today = fresh_today()
	for k in d.get("today", {}).keys():
		if today.has(k):
			today[k] = d.today[k]
	last_day = fresh_today()
	for k in d.get("last_day", {}).keys():
		if last_day.has(k):
			last_day[k] = d.last_day[k]
	next_id = int(d.get("next_id", 1000))
	won = bool(d.get("won", false))
	# animals whose enclosure no longer exists are dropped to an existing one when possible
	rebuild()
	for a in animals:
		if not enc_by_id.has(a.enc) and not encs.is_empty():
			a.enc = encs[0].id
	rebuild()
	sync_staff()
	player.pos = Vector2(Z.GATE.x * T + 16, (Z.GATE.y - 2) * T + 24)
	cam.position = player.pos
	return true


func start_new():
	new_game()
	state = "play"
	ui.show_hud()


func start_continue():
	if load_game():
		state = "play"
		ui.show_hud()


func save_and_menu():
	save_game(true)
	state = "menu"
	ui.show_menu()
