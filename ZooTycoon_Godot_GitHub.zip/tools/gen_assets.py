#!/usr/bin/env python3
"""Generates the pixel-art sprites used by the game (16x16 grid, upscaled x2 -> 32x32).
Replace any PNG in assets/ with your own art using the same file name."""
import os, random
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
K = (20, 16, 14, 255)  # outline/eye


def c(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def canvas(w=16, h=16):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def save(img, sub, name, scale=2):
    p = os.path.join(ROOT, sub)
    os.makedirs(p, exist_ok=True)
    img = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    img.save(os.path.join(p, name + ".png"))


def px(d, x, y, col):
    d.point((x, y), fill=col)


def rect(d, x0, y0, x1, y1, col):
    d.rectangle([x0, y0, x1, y1], fill=col)


def shade(col, f):
    return (max(0, min(255, int(col[0] * f))), max(0, min(255, int(col[1] * f))),
            max(0, min(255, int(col[2] * f))), 255)


# ---------------------------------------------------------------- terrain
def terrain():
    for name, base, seed in (("grass_a", "#58aa46", 1), ("grass_b", "#5fb34c", 2), ("dirt", "#a8845a", 3), ("path", "#d2bd8c", 4)):
        img, d = canvas()
        rect(d, 0, 0, 15, 15, c(base))
        r = random.Random(seed)
        for _ in range(22):
            x, y = r.randint(0, 15), r.randint(0, 15)
            px(d, x, y, shade(c(base), r.choice((0.88, 1.1))))
        if name == "path":
            for x in range(16):
                px(d, x, 0, shade(c(base), 0.92))
                px(d, x, 15, shade(c(base), 0.92))
        save(img, "terrain", name)


# ---------------------------------------------------------------- fences
def fences():
    wood, dark = (225, 220, 210, 255), (150, 145, 135, 255)
    img, d = canvas()
    rect(d, 0, 5, 15, 6, wood); rect(d, 0, 9, 15, 10, wood)
    rect(d, 0, 6, 15, 6, dark); rect(d, 0, 10, 15, 10, dark)
    for x in (0, 14):
        rect(d, x, 3, x + 1, 12, wood); rect(d, x + 1, 3, x + 1, 12, dark)
    save(img, "fences", "fence_h")
    img, d = canvas()
    rect(d, 5, 0, 6, 15, wood); rect(d, 9, 0, 10, 15, wood)
    rect(d, 6, 0, 6, 15, dark); rect(d, 10, 0, 10, 15, dark)
    for y in (0, 14):
        rect(d, 3, y, 12, y + 1, wood); rect(d, 3, y + 1, 12, y + 1, dark)
    save(img, "fences", "fence_v")
    img, d = canvas()
    rect(d, 5, 3, 10, 14, wood); rect(d, 10, 3, 10, 14, dark); rect(d, 5, 3, 10, 4, (255, 255, 255, 255))
    save(img, "fences", "fence_c")


# ---------------------------------------------------------------- buildings & props
def props():
    # entrance gate
    img, d = canvas()
    for x in (1, 12):
        rect(d, x, 3, x + 2, 15, c("#7a4a25")); rect(d, x + 2, 3, x + 2, 15, c("#5a3418"))
    rect(d, 0, 1, 15, 4, c("#c0392b")); rect(d, 0, 4, 15, 4, c("#8e2a20"))
    rect(d, 5, 2, 10, 3, c("#f7d44c"))
    save(img, "buildings", "gate")
    # kiosk
    img, d = canvas()
    rect(d, 2, 7, 13, 14, c("#e8d9b0")); rect(d, 2, 11, 13, 12, c("#7a4a25"))
    for i, x in enumerate(range(1, 15, 2)):
        rect(d, x, 3, x + 1, 7, c("#e74c3c") if i % 2 == 0 else c("#f5f5f5"))
    rect(d, 1, 7, 14, 7, c("#8e2a20"))
    rect(d, 5, 8, 10, 10, c("#8fd3f4"))
    save(img, "buildings", "kiosk")
    # bench
    img, d = canvas()
    rect(d, 1, 7, 14, 9, c("#a0652d")); rect(d, 1, 9, 14, 9, c("#734616"))
    rect(d, 1, 4, 14, 5, c("#b9783a"))
    rect(d, 2, 10, 3, 13, c("#3a3a3a")); rect(d, 12, 10, 13, 13, c("#3a3a3a"))
    save(img, "props", "bench_h")
    save(img.rotate(90, expand=True), "props", "bench_v")
    # lamp
    img, d = canvas()
    rect(d, 7, 5, 8, 14, c("#444b55")); rect(d, 5, 14, 10, 15, c("#444b55"))
    rect(d, 5, 1, 10, 5, c("#ffe27a")); rect(d, 5, 1, 10, 1, c("#444b55")); rect(d, 6, 2, 9, 4, c("#fff3b0"))
    save(img, "props", "lamp")
    # bin
    img, d = canvas()
    rect(d, 4, 5, 11, 14, c("#2f8f5b")); rect(d, 3, 4, 12, 5, c("#226c43"))
    for x in (6, 8, 10):
        rect(d, x, 7, x, 12, c("#226c43"))
    save(img, "props", "bin")
    # tree (16x24)
    img, d = canvas(16, 24)
    rect(d, 7, 14, 8, 22, c("#6b4423"))
    d.ellipse([1, 1, 14, 16], fill=c("#2f8a3c"))
    d.ellipse([3, 2, 10, 8], fill=c("#3fae4e"))
    d.ellipse([8, 8, 13, 14], fill=c("#267333"))
    save(img, "props", "tree")
    # eggs
    for name, base, spot in (("egg", "#f6ecd2", "#c9b27a"), ("dino_egg", "#9bd18a", "#3d7a37")):
        img, d = canvas()
        d.ellipse([3, 1, 12, 14], fill=c(base), outline=K)
        for (x, y) in ((6, 5), (9, 8), (5, 10), (8, 3)):
            px(d, x, y, c(spot))
        save(img, "props", name)
    img, d = canvas()
    d.rounded_rectangle([3, 1, 12, 14], radius=4, fill=c("#6ec6ff"), outline=K)
    rect(d, 3, 7, 12, 8, c("#ffffff")); rect(d, 5, 3, 6, 5, c("#d6f0ff"))
    save(img, "props", "capsule")


# ---------------------------------------------------------------- people
def person(name, sub, shirt, pants, hair, hat=None, skin="#f1c27d"):
    img, d = canvas()
    rect(d, 6, 2, 9, 5, c(skin)); rect(d, 6, 1, 9, 2, c(hair))
    px(d, 7, 4, K); px(d, 9, 4, K)
    rect(d, 5, 6, 10, 10, c(shirt)); rect(d, 3, 6, 4, 9, c(shirt)); rect(d, 11, 6, 12, 9, c(shirt))
    rect(d, 3, 10, 4, 10, c(skin)); rect(d, 11, 10, 12, 10, c(skin))
    rect(d, 5, 11, 7, 14, c(pants)); rect(d, 8, 11, 10, 14, c(pants))
    rect(d, 5, 15, 7, 15, K); rect(d, 8, 15, 10, 15, K)
    if hat:
        rect(d, 5, 0, 10, 1, c(hat)); rect(d, 4, 2, 11, 2, c(hat))
    save(img, sub, name)


def people():
    person("visitor_0", "visitors", "#e74c3c", "#34495e", "#3b2a1a")
    person("visitor_1", "visitors", "#3498db", "#7f8c8d", "#e8c15a")
    person("visitor_2", "visitors", "#f39c12", "#2c3e50", "#222222", skin="#c68642")
    person("visitor_3", "visitors", "#9b59b6", "#34495e", "#8b4513", skin="#8d5524")
    person("player", "visitors", "#2ecc71", "#1f3a5f", "#3b2a1a", hat="#f7d44c")
    person("staff_keeper", "visitors", "#7a5a2c", "#4b3a1c", "#3b2a1a", hat="#a07a3a")
    person("staff_vet", "visitors", "#f5f5f5", "#4aa3c7", "#3b2a1a", hat="#ffffff")
    person("staff_cleaner", "visitors", "#2980b9", "#1c4d70", "#3b2a1a", hat="#2980b9")
    person("staff_mechanic", "visitors", "#e67e22", "#3a3a3a", "#3b2a1a", hat="#f1c40f")
    person("staff_guard", "visitors", "#2c3e50", "#1b2631", "#222222", hat="#1b2631")
    person("staff_admin", "visitors", "#ecf0f1", "#2c3e50", "#3b2a1a")


# ---------------------------------------------------------------- animals
def quad(d, body, dark, light, bx=(3, 11), by=(6, 10), head=(11, 4, 14, 8), legs=(3, 5, 9, 11), ly=(11, 13), tail=True):
    rect(d, bx[0], by[0], bx[1], by[1], body)
    rect(d, bx[0], by[1], bx[1], by[1], light)
    rect(d, bx[0], by[0], bx[1], by[0], shade(body, 1.12))
    for lx in legs:
        rect(d, lx, ly[0], lx, ly[1], dark)
    rect(d, head[0], head[1], head[2], head[3], body)
    px(d, head[2] - 1, head[1] + 1, K)
    if tail:
        rect(d, bx[0] - 1, by[0], bx[0] - 1, by[0] + 2, dark)


def a_ayam(d):
    d.ellipse([3, 6, 11, 13], fill=c("#f5f5f0")); rect(d, 9, 3, 12, 7, c("#f5f5f0"))
    rect(d, 10, 1, 11, 2, c("#d63031")); rect(d, 13, 5, 14, 5, c("#f9a825")); px(d, 11, 4, K)
    rect(d, 5, 13, 5, 15, c("#f9a825")); rect(d, 8, 13, 8, 15, c("#f9a825")); rect(d, 2, 6, 3, 8, c("#d8d8d0"))


def a_kelinci(d):
    quad(d, c("#e8e0d6"), c("#bdb3a6"), c("#ffffff"), bx=(4, 11), by=(7, 11), head=(11, 6, 14, 10), legs=(5, 9), ly=(12, 13))
    rect(d, 11, 1, 11, 5, c("#e8e0d6")); rect(d, 13, 1, 13, 5, c("#e8e0d6")); px(d, 12, 3, c("#f4a6b8"))
    px(d, 3, 8, c("#ffffff")); px(d, 3, 9, c("#ffffff"))


def a_kura(d):
    d.ellipse([2, 5, 12, 13], fill=c("#3d8b4a"), outline=c("#26532e"))
    for (x, y) in ((5, 7), (8, 7), (6, 10), (9, 10)):
        px(d, x, y, c("#26532e"))
    rect(d, 12, 8, 14, 11, c("#9bc46b")); px(d, 13, 9, K)
    for x in (4, 10):
        rect(d, x, 13, x + 1, 14, c("#9bc46b"))


def a_rusa(d):
    quad(d, c("#b07b4a"), c("#6b4a2a"), c("#e8d3b0"), ly=(11, 14), head=(11, 3, 14, 7))
    for (x, y) in ((5, 7), (8, 8), (7, 6)):
        px(d, x, y, c("#f3e4c8"))
    rect(d, 11, 0, 11, 2, c("#e0c9a0")); rect(d, 13, 0, 13, 2, c("#e0c9a0")); px(d, 10, 1, c("#e0c9a0")); px(d, 14, 1, c("#e0c9a0"))


def a_zebra(d):
    quad(d, c("#f4f4f4"), c("#303030"), c("#d8d8d8"), ly=(11, 14), head=(11, 3, 14, 7))
    for x in (4, 6, 8, 10):
        rect(d, x, 6, x, 10, c("#222222"))
    rect(d, 11, 3, 11, 7, c("#222222")); rect(d, 12, 3, 12, 3, c("#222222")); px(d, 13, 6, c("#222222"))
    rect(d, 2, 6, 2, 9, c("#222222"))


def a_unta(d):
    d.ellipse([3, 7, 11, 12], fill=c("#3a3a3a"))
    rect(d, 2, 7, 3, 9, c("#f0f0f0"))
    rect(d, 10, 2, 11, 8, c("#e8b89a")); rect(d, 10, 1, 13, 3, c("#e8b89a")); px(d, 12, 2, K); px(d, 14, 2, c("#f9a825"))
    for x in (6, 9):
        rect(d, x, 12, x, 15, c("#e8b89a"))


def a_singa(d):
    quad(d, c("#d9a441"), c("#8a5a1c"), c("#f0d28a"), head=(11, 4, 14, 8), ly=(11, 13))
    rect(d, 10, 3, 13, 9, c("#7a4a1a")); rect(d, 11, 4, 14, 8, c("#d9a441")); px(d, 13, 5, K)
    rect(d, 1, 6, 2, 9, c("#8a5a1c")); px(d, 1, 10, c("#7a4a1a"))


def a_harimau(d):
    quad(d, c("#e8862a"), c("#3a2410"), c("#fff0d6"), head=(11, 4, 14, 8), ly=(11, 13))
    for x in (4, 6, 8, 10):
        rect(d, x, 6, x, 9, c("#1d1208"))
    px(d, 12, 4, c("#1d1208")); px(d, 13, 7, c("#fff0d6")); rect(d, 1, 6, 2, 8, c("#e8862a")); px(d, 1, 7, c("#1d1208"))


def a_beruang(d):
    quad(d, c("#6b4a30"), c("#3a2616"), c("#7d5a3c"), bx=(2, 11), by=(5, 11), head=(10, 3, 14, 8), legs=(3, 5, 9, 11), ly=(12, 14))
    px(d, 11, 2, c("#6b4a30")); px(d, 13, 2, c("#6b4a30")); rect(d, 13, 6, 14, 7, c("#d9b38c"))


def a_gajah(d):
    quad(d, c("#8f98a3"), c("#5d6670"), c("#a8b0b9"), bx=(2, 11), by=(3, 10), head=(10, 3, 13, 8), legs=(3, 5, 9, 11), ly=(11, 14), tail=False)
    rect(d, 13, 6, 14, 12, c("#8f98a3")); rect(d, 14, 12, 15, 12, c("#8f98a3"))
    rect(d, 8, 5, 10, 9, c("#a8b0b9")); px(d, 12, 4, K); rect(d, 12, 9, 13, 10, c("#f5f0e0"))


def dino_base(d, body, dark, light):
    return dict(body=body, dark=dark, light=light)


def a_raptor(d):
    b, dk, lt = c("#4f9d4a"), c("#2d5a2a"), c("#c9e29a")
    rect(d, 4, 6, 10, 10, b); rect(d, 4, 10, 10, 10, lt); rect(d, 10, 3, 14, 7, b); rect(d, 13, 6, 14, 7, lt)
    px(d, 12, 4, K); rect(d, 0, 7, 3, 8, b); rect(d, 0, 6, 1, 6, dk)
    rect(d, 5, 11, 5, 14, dk); rect(d, 9, 11, 9, 14, dk); px(d, 10, 14, c("#f5f5f5"))
    for x in (5, 7, 9):
        px(d, x, 6, dk)
    rect(d, 10, 8, 11, 8, dk)


def a_stego(d):
    b, dk = c("#6f8f3a"), c("#3d5420")
    quad(d, b, dk, c("#a8c06a"), bx=(3, 12), by=(7, 11), head=(12, 8, 14, 10), legs=(4, 6, 10, 12), ly=(12, 14), tail=False)
    for i, x in enumerate(range(4, 12, 2)):
        rect(d, x, 3 + abs(i - 2) // 2 + 1, x + 1, 6, c("#e8742a"))
    rect(d, 0, 9, 2, 10, b); px(d, 0, 8, c("#e8e0c0")); px(d, 1, 8, c("#e8e0c0")); px(d, 13, 9, K)


def a_trike(d):
    b, dk = c("#8f7a5a"), c("#5a4a34")
    quad(d, b, dk, c("#c0a984"), bx=(2, 10), by=(6, 11), head=(10, 5, 14, 10), legs=(3, 5, 8, 10), ly=(12, 14))
    rect(d, 9, 2, 11, 6, c("#d4604a")); rect(d, 9, 2, 9, 6, c("#a8412e"))
    rect(d, 13, 2, 13, 5, c("#f5f0e0")); rect(d, 14, 6, 14, 7, c("#f5f0e0")); px(d, 12, 6, K)
    rect(d, 12, 3, 12, 5, c("#f5f0e0"))


def a_trex(d):
    b, dk, lt = c("#6a7d3a"), c("#38441d"), c("#c9c98a")
    rect(d, 3, 5, 10, 10, b); rect(d, 3, 10, 10, 10, lt)
    rect(d, 9, 1, 15, 6, b); rect(d, 10, 6, 15, 6, lt); px(d, 12, 3, K)
    rect(d, 11, 5, 14, 5, c("#f5f5f5"))
    rect(d, 0, 6, 2, 9, b); rect(d, 0, 7, 0, 8, dk)
    rect(d, 4, 11, 5, 15, dk); rect(d, 8, 11, 9, 15, dk); rect(d, 10, 7, 11, 8, dk)


def a_brachio(d):
    b, dk, lt = c("#6a8caa"), c("#3d566e"), c("#b6cfe0")
    quad(d, b, dk, lt, bx=(2, 10), by=(8, 12), head=(10, 8, 11, 9), legs=(3, 5, 8, 10), ly=(13, 15), tail=False)
    rect(d, 10, 2, 11, 9, b); rect(d, 10, 1, 13, 3, b); px(d, 12, 2, K)
    rect(d, 0, 10, 1, 11, b); rect(d, 3, 8, 8, 8, shade(b, 1.15))


def a_spino(d):
    b, dk = c("#2f8f8a"), c("#1b524f")
    quad(d, b, dk, c("#a6e0d8"), bx=(3, 10), by=(7, 11), head=(10, 4, 15, 8), legs=(4, 8), ly=(12, 15))
    for x in range(4, 10):
        rect(d, x, 2 + abs(x - 7) // 2, x, 6, c("#d9534f"))
    rect(d, 0, 8, 2, 9, b); px(d, 13, 5, K); rect(d, 12, 8, 14, 8, c("#f5f5f5"))


ANIMALS = {
    "animals": [("ayam", a_ayam), ("kelinci", a_kelinci), ("kura", a_kura), ("rusa", a_rusa), ("zebra", a_zebra),
                ("unta", a_unta), ("singa", a_singa), ("harimau", a_harimau), ("beruang", a_beruang), ("gajah", a_gajah)],
    "dinosaurs": [("raptor", a_raptor), ("stego", a_stego), ("trike", a_trike), ("trex", a_trex),
                  ("brachio", a_brachio), ("spino", a_spino)],
}


def animals():
    for sub, lst in ANIMALS.items():
        for name, fn in lst:
            img, d = canvas()
            fn(d)
            save(img, sub, name)


def icon():
    img, d = canvas(32, 32)
    rect(d, 0, 0, 31, 31, c("#58aa46"))
    d.ellipse([4, 8, 27, 29], fill=c("#e8b04a"), outline=K)
    d.ellipse([9, 15, 15, 20], fill=(255, 255, 255, 255)); d.ellipse([17, 15, 23, 20], fill=(255, 255, 255, 255))
    px(d, 12, 18, K); px(d, 20, 18, K); rect(d, 13, 23, 18, 24, K)
    img = img.resize((192, 192), Image.NEAREST)
    img.save(os.path.join(ROOT, "..", "icon.png"))


if __name__ == "__main__":
    terrain(); fences(); props(); people(); animals(); icon()
    print("assets generated")
