# ZOO TYCOON: FROM BROKE TO BILLIONAIRE
Godot 4.3 (GDScript), 2D top-down pixel-art zoo simulator. Bahasa Indonesia.

## Build APK lewat GitHub
1. Upload **isi** folder ini ke repo GitHub (project.godot harus ada di root repo).
2. Push ke branch `main` -> tab **Actions** -> workflow "Build Android APK" berjalan (atau jalankan manual).
3. Unduh artifact `ZooTycoon-APK` (APK debug, bisa langsung diinstal).

## Menjalankan di PC
Buka folder di Godot 4.3+, tekan F5.

## Sprite
`assets/` berisi sprite pixel-art buatan `tools/gen_assets.py` (placeholder konsisten). Ganti PNG mana pun
dengan nama file yang sama (32x32 untuk hewan/orang/tile) untuk memakai sprite sheet milikmu.

## Kontrol
WASD/panah atau joystick = jalan | seret/klik kanan = geser kamera | roda mouse atau +/- = zoom | R putar | B bangun | Spasi jeda.
